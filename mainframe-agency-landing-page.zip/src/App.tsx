import React, { useState, useEffect, useRef } from 'react';
import { Linkedin, Instagram, Dribbble, BookOpen, GraduationCap, Sparkles, Calendar, ArrowRight } from 'lucide-react';
import { AboutView } from './components/AboutView';
import { ProjectsView } from './components/ProjectsView';
import { LearnView } from './components/LearnView';
import { ArticlesView } from './components/ArticlesView';
import ContactView from './components/ContactView';

// Custom Typewriter Hook as requested
export function useTypewriter(text: string, speed: number = 38, startDelay: number = 600) {
  const [displayed, setDisplayed] = useState('');
  const [done, setDone] = useState(false);

  useEffect(() => {
    let index = 0;
    let intervalId: NodeJS.Timeout | null = null;
    setDisplayed('');
    setDone(false);

    const timeoutId = setTimeout(() => {
      intervalId = setInterval(() => {
        if (index < text.length) {
          setDisplayed((prev) => prev + text.charAt(index));
          index++;
        } else {
          setDone(true);
          if (intervalId) clearInterval(intervalId);
        }
      }, speed);
    }, startDelay);

    return () => {
      clearTimeout(timeoutId);
      if (intervalId) clearInterval(intervalId);
    };
  }, [text, speed, startDelay]);

  return { displayed, done };
}

type ActiveModal = 'pitch' | 'careers' | 'hello' | 'operations' | 'learn' | null;

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showButtons, setShowButtons] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [currentPage, setCurrentPage] = useState<'home' | 'about' | 'projects' | 'learn' | 'articles' | 'contact'>('home');
  
  // Video scrubbing refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const prevXRef = useRef<number | null>(null);
  const targetTimeRef = useRef<number>(0);
  const isSeekingRef = useRef<boolean>(false);

  // Form states inside modals
  const [pitchForm, setPitchForm] = useState({ name: '', email: '', desc: '', budget: '' });
  const [pitchSuccess, setPitchSuccess] = useState(false);

  const [careerForm, setCareerForm] = useState({ name: '', email: '', role: 'Lead Creative Developer', portfolio: '' });
  const [careerSuccess, setCareerSuccess] = useState(false);

  const [helloForm, setHelloForm] = useState({ name: '', message: '' });
  const [helloSuccess, setHelloSuccess] = useState(false);

  const [learnForm, setLearnForm] = useState({ name: '', email: '', course: 'motion' });
  const [learnSuccess, setLearnSuccess] = useState(false);

  // Setup button fade-in delay (400ms after load)
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowButtons(true);
    }, 4000); // Wait 400ms as requested, but wait, the instructions say "visible 400ms after page load, independent of typewriter"
    // Let's use 400ms!
    const quickTimer = setTimeout(() => {
      setShowButtons(true);
    }, 400);
    return () => {
      clearTimeout(timer);
      clearTimeout(quickTimer);
    };
  }, []);

  // Window mouse move listener for video scrubbing
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const video = videoRef.current;
      if (!video || isNaN(video.duration) || video.duration === 0) return;

      if (prevXRef.current === null) {
        prevXRef.current = e.clientX;
        return;
      }

      const delta = e.clientX - prevXRef.current;
      prevXRef.current = e.clientX;

      const SENSITIVITY = 0.8;
      const timeChange = (delta / window.innerWidth) * SENSITIVITY * video.duration;

      let newTarget = targetTimeRef.current + timeChange;
      if (newTarget < 0) newTarget = 0;
      if (newTarget > video.duration) newTarget = video.duration;

      targetTimeRef.current = newTarget;

      if (!isSeekingRef.current) {
        isSeekingRef.current = true;
        video.currentTime = newTarget;
      }
    };

    const handleMouseEnter = (e: MouseEvent) => {
      prevXRef.current = e.clientX;
    };

    const handleMouseLeave = () => {
      prevXRef.current = null;
    };

    // Touch support for full interactive parity on mobile
    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        prevXRef.current = e.touches[0].clientX;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 0) return;
      const currentX = e.touches[0].clientX;

      const video = videoRef.current;
      if (!video || isNaN(video.duration) || video.duration === 0) return;

      if (prevXRef.current === null) {
        prevXRef.current = currentX;
        return;
      }

      const delta = currentX - prevXRef.current;
      prevXRef.current = currentX;

      const SENSITIVITY = 0.8;
      const timeChange = (delta / window.innerWidth) * SENSITIVITY * video.duration;

      let newTarget = targetTimeRef.current + timeChange;
      if (newTarget < 0) newTarget = 0;
      if (newTarget > video.duration) newTarget = video.duration;

      targetTimeRef.current = newTarget;

      if (!isSeekingRef.current) {
        isSeekingRef.current = true;
        video.currentTime = newTarget;
      }
    };

    const handleTouchEnd = () => {
      prevXRef.current = null;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseenter', handleMouseEnter);
    window.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('touchstart', handleTouchStart);
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleTouchEnd);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseenter', handleMouseEnter);
      window.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  // Video metadata & seek handlers
  const handleLoadedMetadata = () => {
    const video = videoRef.current;
    if (video) {
      const startSec = Math.min(3, video.duration || 3);
      video.currentTime = startSec;
      targetTimeRef.current = startSec;
    }
  };

  // Ensure default frame is set if video is already ready on mount
  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      if (video.readyState >= 1) {
        const startSec = Math.min(3, video.duration || 3);
        video.currentTime = startSec;
        targetTimeRef.current = startSec;
      }
    }
  }, []);

  const handleSeeked = () => {
    const video = videoRef.current;
    if (!video) return;

    if (Math.abs(video.currentTime - targetTimeRef.current) > 0.05) {
      video.currentTime = targetTimeRef.current;
    } else {
      isSeekingRef.current = false;
    }
  };

  // Custom clipboard copy action
  const handleCopyEmail = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText('uibashar.design@gmail.com');
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };

  // Custom Typewriter setup
  const { displayed, done } = useTypewriter(
    "_Helping startups and businesses turn complex ideas into simple, beautiful user experiences.\nWhat's your next project?",
    38,
    600
  );

  return (
    <div id="mainframe-app" className={`relative min-h-screen text-white select-none overflow-x-hidden font-body bg-[#0c0c0c] ${currentPage === 'home' ? 'h-screen overflow-hidden' : ''}`}>
      
      {/* 1. BACKGROUND VIDEO (Fixed, Full screen, mouse-scrub controlled) */}
      <video
        id="bg-video"
        ref={videoRef}
        src="https://raw.githubusercontent.com/uiBashar/uibashar.com/main/download.mp4"
        style={{
          position: 'fixed',
          inset: 0,
          zIndex: 0,
          objectFit: 'cover',
          display: currentPage === 'about' ? 'none' : 'block'
        }}
        className={`w-full h-full pointer-events-none opacity-80 transition-all duration-700 ${
          currentPage === 'contact'
            ? '[object-position:80%_center] md:object-center'
            : '[object-position:70%_center]'
        }`}
        muted
        playsInline
        preload="auto"
        onLoadedMetadata={handleLoadedMetadata}
        onSeeked={handleSeeked}
      />

      {/* Elegant Artistic Flair scrim to guarantee high text contrast across different frames */}
      <div className="fixed inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent pointer-events-none z-[1]" />

      {/* 2. NAVBAR (Fixed, z-index: 50) */}
      <nav id="navbar" className="fixed top-0 left-0 w-full z-50 px-5 sm:px-8 md:px-10 py-4 sm:py-5 flex justify-between items-center bg-transparent">
        {/* Logo */}
        <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => { setCurrentPage('home'); setIsMenuOpen(false); setActiveModal(null); }}>
          <span 
            className="text-[18px] sm:text-[22px] tracking-tight text-white font-medium logo-font hover:opacity-80 transition-opacity"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            uiBashar
          </span>
        </div>

        {/* Desktop Nav Links */}
        <div className="hidden md:flex flex-row items-center gap-6 text-[17px] tracking-tight">
          <button 
            onClick={() => { setCurrentPage('about'); setActiveModal(null); setIsMenuOpen(false); }} 
            className={`transition-all bg-transparent border-none cursor-pointer pb-[2px] ${currentPage === 'about' && !activeModal ? 'text-white border-b border-white/40 font-medium' : 'text-white/60 hover:text-white'}`}
          >
            About
          </button>
          <button 
            onClick={() => { setCurrentPage('projects'); setActiveModal(null); setIsMenuOpen(false); }} 
            className={`transition-all bg-transparent border-none cursor-pointer pb-[2px] ${currentPage === 'projects' && !activeModal ? 'text-white border-b border-white/40 font-medium' : 'text-white/60 hover:text-white'}`}
          >
            Projects
          </button>
          <button 
            onClick={() => { setCurrentPage('articles'); setActiveModal(null); setIsMenuOpen(false); }} 
            className={`transition-all bg-transparent border-none cursor-pointer pb-[2px] ${currentPage === 'articles' && !activeModal ? 'text-white border-b border-white/40 font-medium' : 'text-white/60 hover:text-white'}`}
          >
            Articles
          </button>
          <button 
            onClick={() => { setCurrentPage('learn'); setActiveModal(null); setIsMenuOpen(false); }} 
            className={`transition-all bg-transparent border-none cursor-pointer pb-[2px] ${currentPage === 'learn' && !activeModal ? 'text-white border-b border-white/40 font-medium' : 'text-white/60 hover:text-white'}`}
          >
            Learn with Me
          </button>

        </div>

        {/* Desktop CTA */}
        <div className="hidden md:block">
          <button 
            onClick={() => { setCurrentPage('contact'); setActiveModal(null); setIsMenuOpen(false); }} 
            className={`text-[17px] ${currentPage === 'contact' && !activeModal ? 'text-white font-medium underline underline-offset-4' : 'text-white/60 hover:text-white underline underline-offset-4'} transition-all bg-transparent border-none cursor-pointer p-0`}
          >
            Contact Us
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <button 
          id="mobile-hamburger"
          onClick={() => setIsMenuOpen(!isMenuOpen)} 
          className="flex flex-col gap-[4px] md:hidden focus:outline-none z-50 cursor-pointer p-2"
          aria-label="Toggle menu"
        >
          <div className={`w-5 h-[2px] bg-white transition-all duration-300 ${isMenuOpen ? 'rotate-45 translate-y-[6px]' : ''}`} />
          <div className={`w-5 h-[2px] bg-white transition-all duration-300 ${isMenuOpen ? 'opacity-0' : ''}`} />
          <div className={`w-5 h-[2px] bg-white transition-all duration-300 ${isMenuOpen ? '-rotate-45 -translate-y-[6px]' : ''}`} />
        </button>
      </nav>

      {/* Mobile Overlay Menu */}
      <div
        id="mobile-overlay"
        className={`fixed inset-0 bg-black/95 backdrop-blur-md flex flex-col justify-center items-start px-8 gap-8 z-[45] md:hidden transition-opacity duration-300 ${
          isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <button 
          onClick={() => { setIsMenuOpen(false); setCurrentPage('about'); setActiveModal(null); }} 
          className={`text-[32px] font-medium hover:opacity-60 transition-opacity text-left bg-transparent border-none cursor-pointer ${currentPage === 'about' && !activeModal ? 'text-white underline underline-offset-8' : 'text-white/60'}`}
        >
          About
        </button>
        <button 
          onClick={() => { setIsMenuOpen(false); setCurrentPage('projects'); setActiveModal(null); }} 
          className={`text-[32px] font-medium hover:opacity-60 transition-opacity text-left bg-transparent border-none cursor-pointer ${currentPage === 'projects' && !activeModal ? 'text-white underline underline-offset-8' : 'text-white/60'}`}
        >
          Projects
        </button>
        <button 
          onClick={() => { setIsMenuOpen(false); setCurrentPage('articles'); setActiveModal(null); }} 
          className={`text-[32px] font-medium hover:opacity-60 transition-opacity text-left bg-transparent border-none cursor-pointer ${currentPage === 'articles' && !activeModal ? 'text-white underline underline-offset-8' : 'text-white/60'}`}
        >
          Articles
        </button>
        <button 
          onClick={() => { setIsMenuOpen(false); setCurrentPage('learn'); setActiveModal(null); }} 
          className={`text-[32px] font-medium hover:opacity-60 transition-opacity text-left bg-transparent border-none cursor-pointer ${currentPage === 'learn' && !activeModal ? 'text-white underline underline-offset-8' : 'text-white/60'}`}
        >
          Learn with Me
        </button>

        <button 
          onClick={() => { setIsMenuOpen(false); setCurrentPage('contact'); setActiveModal(null); }} 
          className={`text-[32px] font-medium hover:opacity-60 transition-opacity text-left bg-transparent border-none cursor-pointer ${currentPage === 'contact' && !activeModal ? 'text-white underline underline-offset-8' : 'text-white/60'}`}
        >
          Contact Us
        </button>
      </div>

      {/* 3. MAIN CONTENT */}
      {currentPage === 'home' ? (
        <main 
          id="hero-section" 
          className="relative z-[2] h-screen flex flex-col justify-center py-16 px-5 sm:px-8 md:px-10 overflow-hidden"
        >
          <div className="max-w-2xl relative z-10 transition-transform duration-300 translate-y-16 md:translate-y-0 text-left">
            
            {/* Intro Label */}
            <div 
              id="intro-label"
              className="pointer-events-none select-none mb-6 sm:mb-8 text-left"
              style={{
                fontSize: 'clamp(20px, 4.2vw, 27px)',
                lineHeight: 1.35,
                fontWeight: 500,
                color: '#fff'
              }}
            >
              Hey there, meet Odri,<br />
              uiBashar's Adaptive Response Interface Agent
            </div>

            {/* Typewriter text */}
            <p 
              id="typewriter-text"
              className="text-white mb-6 sm:mb-8 font-medium min-h-[54px] text-left"
              style={{
                fontSize: 'clamp(20px, 4.2vw, 27px)',
                lineHeight: 1.35,
                whiteSpace: 'pre-line',
                fontWeight: 500
              }}
            >
              {displayed}
              {!done && (
                <span 
                  className="inline-block w-[2px] h-[1.1em] bg-white align-middle ml-[2px] cursor-blink"
                  aria-hidden="true"
                />
              )}
            </p>

            {/* Action pill buttons container */}
            <div 
              id="action-pills"
              style={{
                opacity: showButtons ? 1 : 0,
                transform: showButtons ? 'translateY(0)' : 'translateY(8px)',
                transition: 'opacity 0.4s ease, transform 0.4s ease'
              }}
              className="flex flex-wrap gap-2 justify-start"
            >
              {/* Pill 1: Pitch */}
              <button
                onClick={() => setActiveModal('pitch')}
                className="pill-shadow bg-white text-black border border-black/10 rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.5em] hover:bg-black hover:text-white hover:border-white/20 transition-all duration-200 cursor-pointer whitespace-nowrap"
              >
                Pitch us an idea
              </button>

              {/* Pill 3: Brief Hello */}
              <button
                onClick={() => { setCurrentPage('contact'); setActiveModal(null); }}
                className="pill-shadow bg-white text-black border border-black/10 rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.5em] hover:bg-black hover:text-white hover:border-white/20 transition-all duration-200 cursor-pointer whitespace-nowrap"
              >
                Send a brief hello
              </button>

              {/* Pill 5: Outline copied button */}
              <button
                onClick={handleCopyEmail}
                className="group flex items-center gap-3 bg-transparent border border-white rounded-full text-[13px] sm:text-[15px] px-4 sm:px-5 py-[0.5em] text-white hover:bg-white hover:text-black transition-all cursor-pointer whitespace-nowrap"
              >
                <span>
                  {copied ? "Copied!" : (
                    <>Reach us: <span className="underline underline-offset-2">uibashar.design@gmail.com</span></>
                  )}
                </span>
                <svg 
                  width="12" 
                  height="12" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="w-3 h-3 flex-shrink-0 fill-current"
                >
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>

            </div>
          </div>
        </main>
      ) : currentPage === 'about' ? (
        <AboutView 
          onBackToHome={() => setCurrentPage('home')} 
          onOpenModal={setActiveModal} 
        />
      ) : currentPage === 'learn' ? (
        <LearnView 
          onBackToHome={() => setCurrentPage('home')} 
          onOpenModal={setActiveModal} 
        />
      ) : currentPage === 'articles' ? (
        <ArticlesView 
          onBackToHome={() => setCurrentPage('home')} 
          onOpenModal={setActiveModal} 
        />
      ) : currentPage === 'contact' ? (
        <ContactView 
          onBackToHome={() => setCurrentPage('home')} 
        />

      ) : (
        <ProjectsView 
          onBackToHome={() => setCurrentPage('home')} 
          onOpenModal={setActiveModal} 
        />
      )}

      {/* Bottom Interface Accent */}
      <div className="fixed bottom-8 right-8 z-10 hidden sm:block pointer-events-none">
        <div 
          className="text-[11px] uppercase tracking-widest text-white/40 font-medium select-none"
          style={{ writingMode: 'vertical-rl' }}
        >
          EST 2026 © UIBASHAR
        </div>
      </div>

      {/* Bottom Left Social Links */}
      <div className="fixed bottom-6 left-5 sm:bottom-8 sm:left-8 z-20 flex items-center gap-4 sm:gap-4.5">
        <a 
          href="https://www.linkedin.com/in/uibashar/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/70 hover:text-white hover:border-white/40 hover:bg-white/5 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer bg-black/10 backdrop-blur-sm"
          aria-label="LinkedIn"
        >
          <Linkedin className="w-[18px] h-[18px]" strokeWidth={1.5} />
        </a>
        <a 
          href="https://dribbble.com/uiBashar" 
          target="_blank" 
          rel="noopener noreferrer"
          className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/70 hover:text-white hover:border-white/40 hover:bg-white/5 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer bg-black/10 backdrop-blur-sm"
          aria-label="Dribbble"
        >
          <Dribbble className="w-[18px] h-[18px]" strokeWidth={1.5} />
        </a>
        <a 
          href="https://www.instagram.com/ui_bashar/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/70 hover:text-white hover:border-white/40 hover:bg-white/5 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer bg-black/10 backdrop-blur-sm"
          aria-label="Instagram"
        >
          <Instagram className="w-[18px] h-[18px]" strokeWidth={1.5} />
        </a>
      </div>

      {/* 4. MODALS / INTERACTIVE SLIDE-UP DRAWER */}
      {activeModal && (
        <div 
          id="modal-overlay"
          className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4 transition-all duration-300"
          onClick={() => setActiveModal(null)}
        >
          <div 
            id="modal-container"
            className="bg-[#121212] text-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl relative transition-transform duration-300 scale-100 border border-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex justify-between items-center px-6 pt-6 pb-4 border-b border-white/10">
              <h3 
                className="text-xl font-bold tracking-tight text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {activeModal === 'pitch' && 'Pitch us an idea'}
                {activeModal === 'careers' && 'Join the uiBashar team'}
                {activeModal === 'hello' && 'Drop a hello'}
                {activeModal === 'operations' && 'About uiBashar'}
                {activeModal === 'articles' && 'Articles & Insights'}
                {activeModal === 'learn' && 'Learn with Me'}
              </h3>
              <button 
                onClick={() => setActiveModal(null)} 
                className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-lg hover:bg-white/10 transition-colors cursor-pointer text-white focus:outline-none"
              >
                ✕
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto max-h-[75vh]">
              
              {/* Pitch Form */}
              {activeModal === 'pitch' && (
                <div>
                  {pitchSuccess ? (
                    <div className="text-center py-8">
                      <div className="text-4xl mb-4 text-white">✳︎</div>
                      <h4 className="text-lg font-semibold mb-2 text-white">Project Brief Received</h4>
                      <p className="text-gray-400 text-sm">We review potential collaborations weekly. A creative lead will be in touch shortly.</p>
                      <button 
                        onClick={() => { setPitchSuccess(false); setActiveModal(null); }}
                        className="mt-6 bg-white text-black px-5 py-2 rounded-full text-sm font-semibold hover:opacity-85 transition-opacity"
                      >
                        Done
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={(e) => { e.preventDefault(); setPitchSuccess(true); }} className="flex flex-col gap-4">
                      <p className="text-sm text-gray-400 leading-relaxed">
                        We partner with ambitious founders and global brands to design core digital experiences. Tell us what you have in mind.
                      </p>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Your Name</label>
                        <input 
                          type="text" 
                          required 
                          placeholder="Jane Doe"
                          value={pitchForm.name} 
                          onChange={e => setPitchForm({...pitchForm, name: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Email Address</label>
                        <input 
                          type="email" 
                          required 
                          placeholder="jane@organization.com"
                          value={pitchForm.email} 
                          onChange={e => setPitchForm({...pitchForm, email: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Brief Description</label>
                        <textarea 
                          rows={3} 
                          required 
                          placeholder="What are we building together?"
                          value={pitchForm.desc} 
                          onChange={e => setPitchForm({...pitchForm, desc: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white resize-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Estimated Budget</label>
                        <select 
                          value={pitchForm.budget} 
                          onChange={e => setPitchForm({...pitchForm, budget: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-white [&>option]:bg-[#121212] [&>option]:text-white"
                        >
                          <option value="">Select budget range...</option>
                          <option value="25-50k">$25,000 – $50,000</option>
                          <option value="50-100k">$50,000 – $100,000</option>
                          <option value="100k+">$100,000+</option>
                        </select>
                      </div>
                      <button 
                        type="submit" 
                        className="w-full bg-white text-black py-3 rounded-full text-sm font-semibold hover:opacity-90 transition-opacity mt-2 cursor-pointer"
                      >
                        Submit Project Pitch
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* Careers Form */}
              {activeModal === 'careers' && (
                <div>
                  {careerSuccess ? (
                    <div className="text-center py-8">
                      <div className="text-4xl mb-4 text-white">✳︎</div>
                      <h4 className="text-lg font-semibold mb-2 text-white">Application Transmitted</h4>
                      <p className="text-gray-400 text-sm">Thank you for reaching out. If there is a potential match, our team will contact you directly.</p>
                      <button 
                        onClick={() => { setCareerSuccess(false); setActiveModal(null); }}
                        className="mt-6 bg-white text-black px-5 py-2 rounded-full text-sm font-semibold hover:opacity-85 transition-opacity"
                      >
                        Done
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={(e) => { e.preventDefault(); setCareerSuccess(true); }} className="flex flex-col gap-4">
                      <p className="text-sm text-gray-400 leading-relaxed mb-1">
                        We build highly cohesive software, interactions, and media. Currently accepting remote applicants for elite roles at uiBashar.
                      </p>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Choose your Discipline</label>
                        <select 
                          value={careerForm.role} 
                          onChange={e => setCareerForm({...careerForm, role: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-white [&>option]:bg-[#121212] [&>option]:text-white"
                        >
                          <option value="Lead Creative Developer">Lead Creative Developer</option>
                          <option value="Interactive Art Director">Interactive Art Director</option>
                          <option value="Motion Designer">Motion & Core Systems Engineer</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Your Full Name</label>
                        <input 
                          type="text" 
                          required 
                          placeholder="Your Name"
                          value={careerForm.name} 
                          onChange={e => setCareerForm({...careerForm, name: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Your Email</label>
                        <input 
                          type="email" 
                          required 
                          placeholder="you@domain.com"
                          value={careerForm.email} 
                          onChange={e => setCareerForm({...careerForm, email: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Portfolio or GitHub URL</label>
                        <input 
                          type="url" 
                          required 
                          placeholder="https://mywork.com"
                          value={careerForm.portfolio} 
                          onChange={e => setCareerForm({...careerForm, portfolio: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white"
                        />
                      </div>
                      <button 
                        type="submit" 
                        className="w-full bg-white text-black py-3 rounded-full text-sm font-semibold hover:opacity-90 transition-opacity mt-2 cursor-pointer"
                      >
                        Transmit Application
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* Hello Form */}
              {activeModal === 'hello' && (
                <div>
                  {helloSuccess ? (
                    <div className="text-center py-8">
                      <div className="text-4xl mb-4 text-white">✳︎</div>
                      <h4 className="text-lg font-semibold mb-2 text-white">Message Transmitted</h4>
                      <p className="text-gray-400 text-sm">Thanks for stopping by. Have a fantastic day!</p>
                      <button 
                        onClick={() => { setHelloSuccess(false); setActiveModal(null); }}
                        className="mt-6 bg-white text-black px-5 py-2 rounded-full text-sm font-semibold hover:opacity-85 transition-opacity"
                      >
                        Close
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={(e) => { e.preventDefault(); setHelloSuccess(true); }} className="flex flex-col gap-4">
                      <p className="text-sm text-gray-400 leading-relaxed">
                        Don't have a project brief or job query? No worries. Drop a friendly note or ask us anything.
                      </p>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Your Name</label>
                        <input 
                          type="text" 
                          required 
                          placeholder="Name"
                          value={helloForm.name} 
                          onChange={e => setHelloForm({...helloForm, name: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-1">Your Note</label>
                        <textarea 
                          rows={4} 
                          required 
                          placeholder="Say hello..."
                          value={helloForm.message} 
                          onChange={e => setHelloForm({...helloForm, message: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white resize-none"
                        />
                      </div>
                      <button 
                        type="submit" 
                        className="w-full bg-white text-black py-3 rounded-full text-sm font-semibold hover:opacity-90 transition-opacity mt-2 cursor-pointer"
                      >
                        Send Greeting
                      </button>
                    </form>
                  )}
                </div>
              )}





              {/* Operations Information */}
              {activeModal === 'operations' && (
                <div className="flex flex-col gap-6">
                  <p className="text-sm text-gray-400 leading-relaxed">
                    uiBashar is a modern design engineering studio operating at the cross-section of interactive media, advanced frontend code, and intelligent software architecture.
                  </p>

                  <div className="grid grid-cols-1 gap-4 mt-2">
                    <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                      <h4 className="text-sm font-bold uppercase mb-1 text-white">01. Zero Friction</h4>
                      <p className="text-xs text-gray-400">
                        We work in tight, fast-moving pods of expert developers and artists. We don't write endless tickets or build administrative overhead; we design directly in high-fidelity code.
                      </p>
                    </div>

                    <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                      <h4 className="text-sm font-bold uppercase mb-1 text-white">02. Design Engineering</h4>
                      <p className="text-xs text-gray-400">
                        For us, development is part of the design process. Motion curves, layouts, responsive physics, and loading states are handled with extreme mathematical and visual precision.
                      </p>
                    </div>

                    <div className="bg-white/5 border border-white/5 p-4 rounded-2xl">
                      <h4 className="text-sm font-bold uppercase mb-1 text-white">03. Interactive Systems</h4>
                      <p className="text-xs text-gray-400">
                        We build layouts that respond dynamically to human behavior. Every hover, drag, and click creates subtle, physical feedbacks that immerse the user fully.
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-white/10 text-center">
                    <button 
                      onClick={() => setActiveModal('pitch')}
                      className="bg-white text-black text-xs font-semibold px-6 py-3 rounded-full hover:opacity-90 transition-opacity inline-flex items-center gap-2 cursor-pointer"
                    >
                      <span>Ready to build? Pitch us</span>
                      <span>✳︎</span>
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
