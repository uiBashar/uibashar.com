import React, { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Mail, Send, CheckCircle, Copy, ExternalLink, UploadCloud, Paperclip, X, FileText } from 'lucide-react';

const BG_IMAGE_1 = "https://github.com/uiBashar/uibashar.com/blob/main/bg%2010.jpg?raw=true";
const BG_IMAGE_2 = "https://github.com/uiBashar/uibashar.com/blob/main/Frame%201.jpg?raw=true";

const SPOTLIGHT_R = 170;

interface RevealLayerProps {
  image: string;
  cursorX: number;
  cursorY: number;
}

function RevealLayer({ image, cursorX, cursorY }: RevealLayerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const divRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const div = divRef.current;
    if (!canvas || !div) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight) {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Because the container is flipped horizontally via scale-x-[-1],
    // we mirror the target X coordinate so that the spotlight aligns perfectly
    // with the actual cursor position on screen.
    const targetX = window.innerWidth - cursorX;

    const gradient = ctx.createRadialGradient(
      targetX,
      cursorY,
      0,
      targetX,
      cursorY,
      SPOTLIGHT_R
    );

    gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
    gradient.addColorStop(0.4, 'rgba(255, 255, 255, 0.95)');
    gradient.addColorStop(0.6, 'rgba(255, 255, 255, 0.75)');
    gradient.addColorStop(0.75, 'rgba(255, 255, 255, 0.4)');
    gradient.addColorStop(0.88, 'rgba(255, 255, 255, 0.12)');
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(targetX, cursorY, SPOTLIGHT_R, 0, Math.PI * 2);
    ctx.fill();

    try {
      const dataUrl = canvas.toDataURL();
      div.style.maskImage = `url(${dataUrl})`;
      div.style.webkitMaskImage = `url(${dataUrl})`;
    } catch (err) {
      console.error("Canvas toDataURL failed:", err);
    }
  }, [cursorX, cursorY, image]);

  return (
    <>
      <canvas
        ref={canvasRef}
        style={{ display: 'none' }}
        className="absolute inset-0 pointer-events-none"
      />
      <div
        ref={divRef}
        className="absolute inset-0 bg-center bg-cover bg-no-repeat z-30 pointer-events-none scale-x-[-1]"
        style={{
          backgroundImage: `url(${image})`,
          maskSize: '100% 100%',
          WebkitMaskSize: '100% 100%',
          maskRepeat: 'no-repeat',
          WebkitMaskRepeat: 'no-repeat'
        }}
      />
    </>
  );
}

interface ContactViewProps {
  onBackToHome: () => void;
}

export default function ContactView({ onBackToHome }: ContactViewProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [attachments, setAttachments] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStep, setSubmitStep] = useState('');
  const [submitError, setSubmitError] = useState('');
  const [web3FormsKey, setWeb3FormsKey] = useState(() => localStorage.getItem('web3forms_key') || 'e21da6e6-89d2-451c-964e-6ec94239d6bf');
  const [isSuccess, setIsSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const [cursorPos, setCursorPos] = useState({ x: -999, y: -999 });
  const mouse = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const smooth = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouse.current = { x: e.clientX, y: e.clientY };
    };

    window.addEventListener('mousemove', handleMouseMove);

    const updateSpotlight = () => {
      smooth.current.x += (mouse.current.x - smooth.current.x) * 0.25;
      smooth.current.y += (mouse.current.y - smooth.current.y) * 0.25;
      setCursorPos({ x: smooth.current.x, y: smooth.current.y });
      rafRef.current = requestAnimationFrame(updateSpotlight);
    };

    rafRef.current = requestAnimationFrame(updateSpotlight);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText('uibashar.design@gmail.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const newFiles = Array.from(e.dataTransfer.files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
  };

  const removeAttachment = (indexToRemove: number) => {
    setAttachments(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);
    setSubmitError('');
    
    // Simulate premium visual sequence before launching the email client & success page
    const steps = [
      'Packaging creative parameters...',
      attachments.length > 0 ? 'Binding file attachments...' : 'Compiling contact details...',
      web3FormsKey ? 'Establishing Web3Forms gateway handshake...' : 'Preparing local mail engine...',
      web3FormsKey ? 'Uploading payload to secure servers...' : 'Generating mailto payload...'
    ];

    let currentStep = 0;
    setSubmitStep(steps[currentStep]);

    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < steps.length) {
        setSubmitStep(steps[currentStep]);
      } else {
        clearInterval(interval);
        triggerActualSend();
      }
    }, 800);

    const triggerActualSend = async () => {
      if (web3FormsKey) {
        try {
          const form = new FormData();
          form.append("access_key", web3FormsKey.trim());
          form.append("name", formData.name);
          form.append("email", formData.email);
          form.append("subject", formData.subject || "New Project Brief from Portfolio");

          // Web3Forms free tier restricts binary file uploads with a "Pro feature" block.
          // To guarantee successful delivery to your inbox on the free tier, we embed the file metadata
          // directly in the message text so you know exactly what briefs/files they have prepared,
          // and can easily request them when you reply.
          const fileMetadata = attachments.length > 0 
            ? `\n\n[Attached Brief Files (Web3Forms Free Tier - Reply to this email to request these files)]: \n` + 
              attachments.map(f => `- ${f.name} (${formatFileSize(f.size)})`).join('\n')
            : '';

          form.append("message", formData.message + fileMetadata);

          const response = await fetch("https://api.web3forms.com/submit", {
            method: "POST",
            body: form
          });

          const data = await response.json();
          if (response.ok && data.success) {
            setIsSubmitting(false);
            setIsSuccess(true);
          } else {
            throw new Error(data.message || "Failed to submit form through Web3Forms");
          }
        } catch (error: any) {
          console.error("Web3Forms submission error:", error);
          setSubmitError(error.message || "Unable to send silently. Falling back to email app...");
          // Fall back to mailto on failure
          setTimeout(() => {
            triggerMailtoFallback();
          }, 1500);
        }
      } else {
        triggerMailtoFallback();
      }
    };

    const triggerMailtoFallback = () => {
      // Prepare attachment labels to include in email body text
      const attachmentText = attachments.length > 0 
        ? `\n\n[Attachments ready to upload/attach]:\n` + attachments.map(f => `- ${f.name} (${formatFileSize(f.size)})`).join('\n')
        : '';

      // Trigger the real mailto redirect to send the email
      const mailtoUrl = `mailto:uibashar.design@gmail.com?subject=${encodeURIComponent(formData.subject || 'Inquiry from uiBashar Portfolio')}&body=${encodeURIComponent(
        `Hello Bashar,\n\n${formData.message}${attachmentText}\n\nBest regards,\n${formData.name}\n${formData.email}`
      )}`;
      
      window.location.href = mailtoUrl;

      setIsSubmitting(false);
      setIsSuccess(true);
    };
  };

  const handleReset = () => {
    setFormData({ name: '', email: '', subject: '', message: '' });
    setAttachments([]);
    setIsSuccess(false);
    setSubmitStep('');
  };

  return (
    <div 
      className="min-h-screen bg-black text-white tracking-[-0.02em] relative overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Background artwork - 100% display */}
      <div className="fixed inset-0 pointer-events-none z-10">
        <div 
          className="absolute inset-0 bg-center bg-cover bg-no-repeat scale-x-[-1]" 
          style={{ backgroundImage: `url(${BG_IMAGE_1})` }}
        />
        <RevealLayer 
          image={BG_IMAGE_2}
          cursorX={cursorPos.x}
          cursorY={cursorPos.y}
        />
      </div>

      {/* Main Content Area */}
      <div className="relative z-20 min-h-screen overflow-y-auto pt-28 pb-20">
        <div className="max-w-5xl w-full mx-auto px-5 sm:px-8 md:px-10 flex flex-col gap-10">
          
          {/* Back button */}
          <div>
            <button 
              onClick={onBackToHome}
              className="group flex items-center gap-2.5 text-xs font-semibold uppercase tracking-widest text-white/40 hover:text-white transition-colors cursor-pointer bg-transparent border-none p-0 focus:outline-none"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              <span>Back to Home</span>
            </button>
          </div>

          {/* Grid Layout - Nav Aligned */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            
            {/* Header info - Left column (5 cols) */}
            <div className="lg:col-span-5 flex flex-col gap-4 lg:pt-44 pt-2 lg:sticky lg:top-24">
              
              {/* Header Info (No Card) */}
              <div className="flex flex-col gap-4 pb-2">
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.15em] text-white/40 font-mono">Secure Connection</span>
                  <h1 
                    className="text-3xl sm:text-4xl font-medium tracking-tight text-white leading-tight"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    Let's make it real.
                  </h1>
                </div>

                <p className="text-white/60 text-sm leading-relaxed font-light">
                  Have an ambitious product idea, complex platform requirements, or just want to establish a direct visual handshake? Let's connect.
                </p>
              </div>

              {/* Direct email display */}
              <div className="bg-black/20 border border-white/10 rounded-2xl p-6 flex flex-col gap-4 backdrop-blur-[3px] hover:border-white/25 hover:bg-black/30 transition-all duration-300">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80">
                    <Mail className="w-5 h-5" strokeWidth={1.5} />
                  </div>
                  <div>
                    <p className="text-[10px] text-white/40 font-semibold uppercase tracking-[0.15em] font-mono">Direct Email</p>
                    <p className="text-sm font-medium text-white/90">uibashar.design@gmail.com</p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2.5 mt-1">
                  <button 
                    onClick={handleCopyEmail}
                    className="flex-1 flex items-center justify-center gap-2 text-xs font-medium py-2.5 px-4 rounded-xl border border-white/10 hover:border-white/30 hover:bg-white/5 active:scale-[0.98] transition-all cursor-pointer bg-transparent text-white"
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-white/60" />
                        <span>Copy Address</span>
                      </>
                    )}
                  </button>

                  <a 
                    href="mailto:uibashar.design@gmail.com"
                    className="flex-1 flex items-center justify-center gap-2 text-xs font-medium py-2.5 px-4 rounded-xl bg-white text-black hover:opacity-90 active:scale-[0.98] transition-all text-center"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Send Mail</span>
                  </a>
                </div>
              </div>

            </div>

            {/* Form area - Right column (7 cols) */}
            <div className="lg:col-span-7 bg-black/20 border border-white/10 rounded-3xl p-6 sm:p-8 md:p-10 backdrop-blur-[3px] hover:border-white/25 hover:bg-black/30 transition-all duration-300 shadow-2xl relative overflow-hidden">
              
              {isSubmitting ? (
                /* Submitting State overlay */
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="relative mb-6">
                    <div className="w-12 h-12 rounded-full border-t-2 border-white animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center text-xs font-bold">✳︎</div>
                  </div>
                  <h3 className="text-lg font-medium mb-2 text-white">Transmitting Message</h3>
                  <p className="text-sm text-white/40 font-mono animate-pulse">{submitStep}</p>
                </div>
              ) : isSuccess ? (
                /* Success State view */
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <div className="w-14 h-14 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-6 text-emerald-400">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-medium tracking-tight mb-3">Email Transmission Primed</h3>
                  <p className="text-white/60 text-sm max-w-sm leading-relaxed mb-6">
                    Your local mail client was called to transmit this message. If your browser didn't launch it, click below to send directly:
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-3 w-full max-w-xs">
                    <a 
                      href={`mailto:uibashar.design@gmail.com?subject=${encodeURIComponent(formData.subject)}&body=${encodeURIComponent(formData.message)}`}
                      className="flex-1 bg-white text-black py-3 rounded-xl text-xs font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Trigger Client Again</span>
                    </a>
                    <button 
                      onClick={handleReset}
                      className="flex-1 bg-white/5 border border-white/10 hover:border-white/30 text-white py-3 rounded-xl text-xs font-semibold hover:bg-white/10 transition-colors"
                    >
                      Send Another
                    </button>
                  </div>
                </div>
              ) : (
                /* Interactive Form */
                <form onSubmit={handleSubmit} className="flex flex-col gap-5 sm:gap-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-white/40 mb-2">Your Name</label>
                      <input 
                        type="text" 
                        required 
                        placeholder="Jane Doe"
                        value={formData.name}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 hover:border-white/20 focus:border-white/50 rounded-xl px-4 py-3.5 text-sm text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-white transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-white/40 mb-2">Email Address</label>
                      <input 
                        type="email" 
                        required 
                        placeholder="jane@organization.com"
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 hover:border-white/20 focus:border-white/50 rounded-xl px-4 py-3.5 text-sm text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-white transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-white/40 mb-2">Subject</label>
                    <input 
                      type="text" 
                      required 
                      placeholder="Product Design Collaboration"
                      value={formData.subject}
                      onChange={e => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 hover:border-white/20 focus:border-white/50 rounded-xl px-4 py-3.5 text-sm text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-white transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-white/40 mb-2">Message or Brief</label>
                    <textarea 
                      rows={5} 
                      required 
                      placeholder="Detail your product vision, timeline, and goals..."
                      value={formData.message}
                      onChange={e => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 hover:border-white/20 focus:border-white/50 rounded-xl px-4 py-3.5 text-sm text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-white resize-none transition-all leading-relaxed"
                    />
                  </div>

                  {/* Attachments Dropzone */}
                  <div className="flex flex-col gap-3">
                    <p className="text-xs font-semibold text-white/40 uppercase tracking-wider">Project Attachments / Brief</p>
                    
                    <div 
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={triggerFileInput}
                      className={`border border-dashed rounded-xl p-5 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center gap-2.5 backdrop-blur-md ${
                        isDragging 
                          ? 'border-white bg-white/10' 
                          : 'border-white/10 bg-white/5 hover:border-white/30 hover:bg-white/[0.08]'
                      }`}
                    >
                      <input 
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileSelect}
                        multiple
                        className="hidden"
                      />
                      <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/60">
                        <UploadCloud className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs font-medium text-white/90">Drag & drop files here, or <span className="underline">browse</span></p>
                        <p className="text-[10px] text-white/40 mt-1">Supports PDF, DOCX, ZIP, PNG, JPG, FIG, etc. (Max 25MB)</p>
                      </div>
                    </div>

                    {/* Attachments List */}
                    {attachments.length > 0 && (
                      <div className="flex flex-col gap-2 mt-1">
                        <p className="text-[11px] font-medium text-white/50 px-1">Attached Details ({attachments.length})</p>
                        <div className="max-h-[160px] overflow-y-auto pr-1 flex flex-col gap-1.5 custom-scrollbar">
                          {attachments.map((file, idx) => (
                            <div 
                              key={idx} 
                              className="flex items-center justify-between gap-3 bg-white/5 border border-white/10 rounded-xl py-2 px-3 hover:bg-white/[0.08] transition-colors"
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <FileText className="w-4 h-4 text-white/40 shrink-0" />
                                <div className="min-w-0">
                                  <p className="text-xs font-medium text-white/90 truncate">{file.name}</p>
                                  <p className="text-[10px] text-white/40">{formatFileSize(file.size)}</p>
                                </div>
                              </div>
                              <button 
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeAttachment(idx);
                                }}
                                className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors bg-transparent border-none cursor-pointer"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Silent Send configuration (Web3Forms Key) */}
                  <div className="border-t border-white/10 pt-5 mt-2 flex flex-col gap-2.5">
                    <div className="flex justify-between items-center">
                      <label className="block text-[11px] font-semibold uppercase tracking-wider text-white/40">
                        Direct Inbox Delivery
                      </label>
                      <span className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                        ● Live Preconfigured
                      </span>
                    </div>
                    <input 
                      type="text" 
                      placeholder="Paste your free Web3Forms Access Key here to send silently..."
                      value={web3FormsKey}
                      onChange={e => {
                        const val = e.target.value;
                        setWeb3FormsKey(val);
                        localStorage.setItem('web3forms_key', val);
                      }}
                      className="w-full bg-white/5 border border-white/10 hover:border-white/20 focus:border-white/50 rounded-xl px-4 py-3 text-xs text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-white transition-all font-mono"
                    />
                    <p className="text-[10px] text-white/40 leading-relaxed">
                      Pre-filled with your active key <span className="text-white/60">e21da6e6...</span>. Inquiries and attachment briefs will deliver <strong>directly</strong> and silently to your inbox (<span className="text-white/60">uibashar.design@gmail.com</span>) without interrupting the client!
                    </p>
                  </div>

                  {submitError && (
                    <div className="bg-red-500/10 border border-red-500/20 text-red-300 text-xs py-3 px-4 rounded-xl text-center font-medium mt-1">
                      {submitError}
                    </div>
                  )}

                  <button 
                    type="submit" 
                    className="w-full bg-white text-black py-4 rounded-xl text-sm font-semibold hover:opacity-90 active:scale-[0.99] transition-all cursor-pointer mt-4 flex items-center justify-center gap-2.5 shadow-md shadow-black/20"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Project Request</span>
                  </button>
                </form>
              )}

            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
