import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Figma, 
  Framer, 
  Palette, 
  PenTool, 
  Layers, 
  Type, 
  Aperture, 
  Chrome, 
  Camera, 
  Brush, 
  Box, 
  Wand2,
  Globe,
  Cpu
} from 'lucide-react';

const SPOTLIGHT_R = 170;
const BG_IMAGE_1 = "https://github.com/uiBashar/uibashar.com/blob/main/Frame%201.jpg?raw=true";
const BG_IMAGE_2 = "https://github.com/uiBashar/uibashar.com/blob/main/Frame%202.jpg?raw=true";

interface RevealLayerProps {
  image: string;
  cursorX: number;
  cursorY: number;
}

export function RevealLayer({ image, cursorX, cursorY }: RevealLayerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const divRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const div = divRef.current;
    if (!canvas || !div) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight) {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const gradient = ctx.createRadialGradient(
      cursorX,
      cursorY,
      0,
      cursorX,
      cursorY,
      SPOTLIGHT_R
    );

    gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
    gradient.addColorStop(0.4, 'rgba(255, 255, 255, 0.95)');
    gradient.addColorStop(0.6, 'rgba(255, 255, 255, 0.75)');
    gradient.addColorStop(0.75, 'rgba(255, 255, 255, 0.4)');
    gradient.addColorStop(0.88, 'rgba(255, 255, 255, 0.12)');
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(cursorX, cursorY, SPOTLIGHT_R, 0, Math.PI * 2);
    ctx.fill();

    try {
      const dataUrl = canvas.toDataURL();
      div.style.maskImage = `url(${dataUrl})`;
      div.style.webkitMaskImage = `url(${dataUrl})`;
    } catch (err) {
      console.error("Canvas toDataURL failed:", err);
    }
  }, [cursorX, cursorY, image]);

  return (
    <>
      <canvas
        ref={canvasRef}
        style={{ display: 'none' }}
        className="absolute inset-0 pointer-events-none"
      />
      <div
        ref={divRef}
        className="absolute inset-0 bg-[80%_center] md:bg-center bg-cover bg-no-repeat z-30 pointer-events-none"
        style={{
          backgroundImage: `url(${image})`,
          maskSize: '100% 100%',
          WebkitMaskSize: '100% 100%',
          maskRepeat: 'no-repeat',
          WebkitMaskRepeat: 'no-repeat'
        }}
      />
    </>
  );
}

interface AboutViewProps {
  onBackToHome: () => void;
  onOpenModal: (modal: 'pitch' | 'hello') => void;
}

export function AboutView({ onBackToHome, onOpenModal }: AboutViewProps) {
  const [cursorPos, setCursorPos] = useState({ x: -999, y: -999 });
  const mouse = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const smooth = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouse.current = { x: e.clientX, y: e.clientY };
    };

    window.addEventListener('mousemove', handleMouseMove);

    const updateSpotlight = () => {
      smooth.current.x += (mouse.current.x - smooth.current.x) * 0.25;
      smooth.current.y += (mouse.current.y - smooth.current.y) * 0.25;
      setCursorPos({ x: smooth.current.x, y: smooth.current.y });
      rafRef.current = requestAnimationFrame(updateSpotlight);
    };

    rafRef.current = requestAnimationFrame(updateSpotlight);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  return (
    <div 
      className="min-h-screen bg-black text-white tracking-[-0.02em] relative overflow-hidden" 
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      
      {/* BACKGROUND SPOTLIGHT LAYER (Fixed/Absolute) */}
      <div className="fixed inset-0 pointer-events-none z-10">
        {/* Base image (z-10) */}
        <div 
          className="absolute inset-0 bg-[80%_center] md:bg-center bg-cover bg-no-repeat grayscale" 
          style={{ backgroundImage: `url(${BG_IMAGE_1})` }}
        />

        {/* Reveal layer (z-30) */}
        <RevealLayer 
          image={BG_IMAGE_2} 
          cursorX={cursorPos.x} 
          cursorY={cursorPos.y} 
        />
      </div>

      {/* INTERACTIVE TEXT OVERLAY */}
      <div className="relative z-20 min-h-screen overflow-y-auto pt-28 pb-16">
        <div className="max-w-5xl w-full mx-auto px-5 sm:px-8 md:px-10 flex flex-col gap-8 md:gap-10">
          
          {/* Header section with back button */}
          <div className="flex flex-col gap-4">
            <button 
              onClick={onBackToHome}
              className="group flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 hover:text-white transition-colors w-fit cursor-pointer bg-transparent border-none p-0 focus:outline-none"
            >
              <span className="group-hover:-translate-x-1 transition-transform">←</span>
              <span>Back to Home</span>
            </button>
            
            <h1 
              className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-white leading-[1.15] animate-fade-in-up"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Crafting products at the edge of human behavior.
            </h1>
            
            <p className="text-base sm:text-lg text-white/70 max-w-2xl leading-relaxed mt-1 font-light">
              uiBashar is an elite digital creation studio. We construct highly responsive, tactile, and intelligent software interfaces that turn complex concepts into beautiful, seamless product designs.
            </p>
          </div>

          {/* Core Pillars Grid - Service Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-5xl mx-auto">
            
            {/* Card 1 - UX/UI Product Design */}
            <div className="relative overflow-hidden rounded-2xl bg-black/20 backdrop-blur-[3px] p-6 sm:p-8 border border-white/10 hover:border-white/25 hover:bg-black/30 transition-all duration-300 flex flex-col justify-between min-h-[380px] group">
              <div className="flex flex-col gap-5">
                {/* Icon Container */}
                <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80 group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Palette className="w-6 h-6" strokeWidth={1.5} />
                </div>
                
                <div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-mono font-medium block mb-1">
                    End-to-End Digital Craft
                  </span>
                  <h3 className="text-lg sm:text-xl font-medium tracking-tight text-white font-sans">
                    Product Design (UX/UI)
                  </h3>
                  <p className="text-xs sm:text-sm text-white/60 font-light leading-relaxed mt-2.5">
                    Transforming complex requirements into simple, intuitive, and gorgeous digital interfaces. Designing balanced layouts that combine ultimate usability with modern aesthetics.
                  </p>
                </div>
              </div>

              {/* Deliverables */}
              <div className="mt-8 pt-6 border-t border-white/5 flex flex-col gap-2.5">
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>User Research & Persona Journeys</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>High-Fidelity UI Layout Design</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Interactive Wireframes & IA</span>
                </div>
              </div>
            </div>

            {/* Card 2 - Websites & Web Apps */}
            <div className="relative overflow-hidden rounded-2xl bg-black/20 backdrop-blur-[3px] p-6 sm:p-8 border border-white/10 hover:border-white/25 hover:bg-black/30 transition-all duration-300 flex flex-col justify-between min-h-[380px] group">
              <div className="flex flex-col gap-5">
                {/* Icon Container */}
                <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80 group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Globe className="w-6 h-6" strokeWidth={1.5} />
                </div>
                
                <div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-mono font-medium block mb-1">
                    Responsive Web Experience
                  </span>
                  <h3 className="text-lg sm:text-xl font-medium tracking-tight text-white font-sans">
                    Websites & Web Apps
                  </h3>
                  <p className="text-xs sm:text-sm text-white/60 font-light leading-relaxed mt-2.5">
                    Crafting premium, responsive websites and client-side applications with seamless flow. High performance, polished interactions, and perfect responsive behavior across all viewport ranges.
                  </p>
                </div>
              </div>

              {/* Deliverables */}
              <div className="mt-8 pt-6 border-t border-white/5 flex flex-col gap-2.5">
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Custom Web Development & Prototyping</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Responsive Desktop-to-Mobile Layouts</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Pixel-Perfect Animations & Speed Optimization</span>
                </div>
              </div>
            </div>

            {/* Card 3 - AI-Powered Interfaces */}
            <div className="relative overflow-hidden rounded-2xl bg-black/20 backdrop-blur-[3px] p-6 sm:p-8 border border-white/10 hover:border-white/25 hover:bg-black/30 transition-all duration-300 flex flex-col justify-between min-h-[380px] group">
              <div className="flex flex-col gap-5">
                {/* Icon Container */}
                <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80 group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Cpu className="w-6 h-6" strokeWidth={1.5} />
                </div>
                
                <div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-mono font-medium block mb-1">
                    Intelligence Integration
                  </span>
                  <h3 className="text-lg sm:text-xl font-medium tracking-tight text-white font-sans">
                    AI-Powered Interfaces
                  </h3>
                  <p className="text-xs sm:text-sm text-white/60 font-light leading-relaxed mt-2.5">
                    Designing interfaces for the machine-learning era. Integrating natural language models, semantic tools, and cognitive features into clean, user-friendly interactive flows.
                  </p>
                </div>
              </div>

              {/* Deliverables */}
              <div className="mt-8 pt-6 border-t border-white/5 flex flex-col gap-2.5">
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Prompt Engineering UI & LLM Portals</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Generative Visual & Audio Tooling</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Context-Aware Interactive Flows</span>
                </div>
              </div>
            </div>

            {/* Card 4 - Design Systems & Scale */}
            <div className="relative overflow-hidden rounded-2xl bg-black/20 backdrop-blur-[3px] p-6 sm:p-8 border border-white/10 hover:border-white/25 hover:bg-black/30 transition-all duration-300 flex flex-col justify-between min-h-[380px] group">
              <div className="flex flex-col gap-5">
                {/* Icon Container */}
                <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/80 group-hover:bg-white group-hover:text-black transition-all duration-300">
                  <Layers className="w-6 h-6" strokeWidth={1.5} />
                </div>
                
                <div>
                  <span className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-mono font-medium block mb-1">
                    Modular Component Systems
                  </span>
                  <h3 className="text-lg sm:text-xl font-medium tracking-tight text-white font-sans">
                    Design Systems & Scale
                  </h3>
                  <p className="text-xs sm:text-sm text-white/60 font-light leading-relaxed mt-2.5">
                    Engineering comprehensive, scalable, and modular design tokens in Figma and Framer. Standardizing UI foundations to keep design-to-engineering transitions seamless.
                  </p>
                </div>
              </div>

              {/* Deliverables */}
              <div className="mt-8 pt-6 border-t border-white/5 flex flex-col gap-2.5">
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Scalable Figma Component Libraries</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Design Token Systems (Spacing, Color, Type)</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] sm:text-xs text-white/55 font-sans font-light">
                  <Sparkles className="h-3 w-3 text-white/40 shrink-0" strokeWidth={1.5} />
                  <span>Detailed Developer Handoff Docs</span>
                </div>
              </div>
            </div>

          </div>

          {/* Bottom Call to Action */}
          <div className="flex flex-wrap items-center gap-4 bg-black/20 border border-white/10 p-5 rounded-2xl md:justify-between backdrop-blur-[3px]">
            <div>
              <h4 className="text-sm font-semibold text-white">Have a product vision in mind?</h4>
              <p className="text-[11px] text-white/50 mt-0.5">Let's collaborate on designing your next high-fidelity digital interface.</p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => onOpenModal('pitch')}
                className="bg-white text-black text-xs font-semibold px-4 py-2.5 rounded-full hover:bg-white/90 transition-all cursor-pointer whitespace-nowrap focus:outline-none"
              >
                Pitch an Idea
              </button>
              <button 
                onClick={() => onOpenModal('hello')}
                className="bg-transparent border border-white/20 text-white text-xs font-semibold px-4 py-2.5 rounded-full hover:bg-white hover:text-black hover:border-white transition-all cursor-pointer whitespace-nowrap focus:outline-none"
              >
                Say Hello
              </button>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}
