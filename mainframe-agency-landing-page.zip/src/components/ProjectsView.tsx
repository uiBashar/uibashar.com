import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, ExternalLink, Sparkles, Sliders, Smartphone, Cpu, Shield, Layers, Play, CheckCircle, Heart, Bookmark, Clock } from 'lucide-react';
import { VideoPlayer } from './LearnView';

const BG_IMAGE_1 = "https://github.com/uiBashar/uibashar.com/blob/main/bg1.jpg?raw=true";
const BG_IMAGE_2 = "https://github.com/uiBashar/uibashar.com/blob/main/Frame%202.jpg?raw=true";

interface Project {
  id: string;
  title: string;
  subtitle: string;
  category: 'Interaction' | 'SaaS Systems' | 'Mobile Apps';
  tag: string;
  description: string;
  image: string;
  images?: string[];
  tech: string[];
  role: string;
  year: string;
  details: string;
}

const PROJECTS_DATA: Project[] = [
  {
    id: 'vehix',
    title: 'Vehix | Smart vehicle finder app',
    subtitle: 'Sleek automobile search interface',
    category: 'SaaS Systems',
    tag: 'AI Smart Finder',
    description: 'An intelligent, high-fidelity automobile finder interface that streamlines search mechanics, vehicle telemetry, and visual filter layers.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/main/dahsboard%20(1).jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/main/dahsboard%20(1).jpg?raw=true',
      'https://github.com/uiBashar/uibashar.com/blob/main/dahsboard%20(2).jpg?raw=true',
      'https://github.com/uiBashar/uibashar.com/blob/main/dahsboard%20(3).jpg?raw=true'
    ],
    tech: ['Tailwind CSS', 'Interactive Maps', 'D3 Kinetic', 'Context Cache'],
    role: 'Lead UI/UX Designer & Prototyper',
    year: '2026',
    details: 'Inspired directly by premium automobile and inventory interfaces, Vehix transforms static vehicle arrays into dynamic, visual stories. It leverages custom interactive card structures, high-fidelity filtering layers, and friction-dampened transitions.'
  },
  {
    id: 'flexana',
    title: 'Flexana | Yoga & meditation App',
    subtitle: 'Sleek Wellness & Mindfulness Platform',
    category: 'Mobile Apps',
    tag: 'iOS & Android App',
    description: 'An elegant personal yoga and mindfulness app designed to support mental clarity, physical flexibility, and custom meditation routines with visual breathing tracks.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/9fc7baea86def6952c4029bf18fd01acab54f60a/Dribble%20shoot-1.jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/9fc7baea86def6952c4029bf18fd01acab54f60a/Dribble%20shoot-1.jpg?raw=true',
      'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=1200&q=80'
    ],
    tech: ['React Native', 'Haptic Feedbacks', 'Lottie Animations', 'Audio Graph API'],
    role: 'Principal Wellness Product Designer',
    year: '2026',
    details: 'This companion app guides users through immersive physical postures and meditation sessions. It utilizes breathing pace sync, fluid color gradients reflecting mood metrics, and custom soundscapes to deliver a truly deep zen state.'
  },
  {
    id: 'chronos-dial',
    title: 'Chronos Dial',
    subtitle: 'Tactile Focus Controller',
    category: 'Interaction',
    tag: 'Micro-interaction',
    description: 'An elegant personal focus system replacing rigid inputs with a hardware-grade virtual dial that clicks responsively as you set focus periods.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/main/Dribble%20shoot-7.jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/main/Dribble%20shoot-7.jpg?raw=true',
      'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260325_094440_a3592600-bd1e-49e5-9bce-a73662061d83.mp4',
      'https://stream.mux.com/tLkHO1qZoaaQOUeVWo8hEBeGQfySP02EPS02BmnNFyXys.m3u8'
    ],
    tech: ['Web Audio API', 'React Motion', 'Spring Dynamics'],
    role: 'Creative Interaction Designer',
    year: '2026',
    details: 'Chronos Dial rethinks focus tracking. It renders a beautiful, circular brushed-metal dial that acts as a tactile interface. Setting focus durations triggers high-frequency micro-haptic sound signals and smooth spring alignments.'
  },
  {
    id: 'aura-os',
    title: 'Aura OS',
    subtitle: 'Ambient Space Desktop',
    category: 'Interaction',
    tag: 'Workspace OS',
    description: 'An ambient desktop operating system concept focusing on calm computing, kinetic stacking window managers, and dynamic layout scaling.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/main/mobile%20(4).jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/main/mobile%20(4).jpg?raw=true',
      'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260302_085844_21a8f4b3-dea5-4ede-be16-d53f6973bb14.mp4',
      'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260302_085640_276ea93b-d7da-4418-a09b-2aa5b490e838.mp4'
    ],
    tech: ['Vite', 'CSS Spring', 'Tailwind', 'Circadian Clock API'],
    role: 'Lead Interaction Architect & Creative Developer',
    year: '2026',
    details: 'Aura OS eliminates traditional desktop friction. It dynamically recalibrates the visual canvas based on screen density, ambient lighting, and human circadian rhythms. It introduces magnetic desktop spaces where application cards dock naturally depending on focus priority.'
  },
  {
    id: 'kinecta',
    title: 'Kinecta Intelligence',
    subtitle: 'Motion-Driven Analytics',
    category: 'SaaS Systems',
    tag: 'Data SaaS',
    description: 'High-performance interactive dashboards visualizing live analytics with physics-based springs and reactive data nodes.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/main/web%20(4).jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/main/web%20(4).jpg?raw=true',
      'https://stream.mux.com/sDz01Os9GN02ltJvgikeaUvZWsLRiR5FX5GuadCRkQc7E.m3u8',
      'https://stream.mux.com/E3rAKyTB54G02a702jKVDAsRnWoRXwUss6mjjctaODp8w.m3u8'
    ],
    tech: ['D3.js', 'Recharts', 'Tailwind CSS', 'WebSockets'],
    role: 'Principal UX/UI Engineer',
    year: '2025',
    details: 'Traditional data dashboards are rigid and fail to draw the eye to critical metric fluctuations. Kinecta uses real-time physics simulation to render active metric streams. Fluctuations produce visible spring-back animations, rendering data anomalies naturally detectable at a glance.'
  },
  {
    id: 'morphic',
    title: 'Morphic UI',
    subtitle: 'Elastic System Sandbox',
    category: 'Interaction',
    tag: 'Design System',
    description: 'A tactile, natural interaction design system that replaces rigid web grids with organic spring-elastic structures.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/main/mobile%20(2).jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/main/mobile%20(2).jpg?raw=true',
      'https://stream.mux.com/NcU3HlHeF7CUL86azTTzpy3Tlb00d6iF3BmCdFslMJYM.m3u8',
      'https://stream.mux.com/01yW6GoUz01OTXk5w1Rt1MHkJWlCGIwj46SUONJZ4DJUE.m3u8'
    ],
    tech: ['React Spring', 'Tailwind CSS', 'Friction-Dampening Engine'],
    role: 'Design System Architect',
    year: '2026',
    details: 'Morphic UI is a premium, physics-driven design language that translates real-world kinetic properties into web controls. Buttons compress with resistance, modals bounce when opening, and scrolling contains fluid fluid-inertia dampening.'
  },
  {
    id: 'vapor',
    title: 'Vapor Customizer',
    subtitle: 'WebGL Spatial Showcase',
    category: 'SaaS Systems',
    tag: '3D Customizer',
    description: 'A 60fps real-time customizer designed for luxury electric vehicles, featuring ambient sound synthesis and material reflection shaders.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/main/jkfgh.jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/main/jkfgh.jpg?raw=true',
      'https://customer-cbeadsgr09pnsezs.cloudflarestream.com/12a9780eeb1ea015801a5f55cf2e9d3d/manifest/video.m3u8',
      'https://stream.mux.com/Kec29dVyJgiPdtWaQtPuEiiGHkJIYQAVUJcNiIHUYeo.m3u8'
    ],
    tech: ['WebGL', 'Three.js Shaders', 'Web Audio Synth'],
    role: 'Creative WebGL Lead',
    year: '2025',
    details: 'Vapor offers extreme visual fidelity inside browser sandboxes. Every body panel customizer recalculates real-time glossy mirror reflections, complemented by spatial Web Audio synthesized soundscapes that morph as users zoom.'
  },
  {
    id: 'nidus',
    title: 'Nidus Wallet',
    subtitle: 'Decentralized Cryptographic Vault',
    category: 'Mobile Apps',
    tag: 'iOS & Android App',
    description: 'A secure digital assets wallet converting complex encryption keys into fluid, swipe gesture-based pattern controls.',
    image: 'https://github.com/uiBashar/uibashar.com/blob/main/Dribble%20shoot-5.jpg?raw=true',
    images: [
      'https://github.com/uiBashar/uibashar.com/blob/main/Dribble%20shoot-5.jpg?raw=true',
      'https://stream.mux.com/8wrHPCX2dC3msyYU9ObwqNdm00u3ViXvOSHUMRYSEe5Q.m3u8',
      'https://stream.mux.com/Aa02T7oM1wH5Mk5EEVDYhbZ1ChcdhRsS2m1NYyx4Ua1g.m3u8'
    ],
    tech: ['React Native', 'Secure Enclave Auth', 'Biometrics API'],
    role: 'Product Designer & UX Researcher',
    year: '2026',
    details: 'Nidus completely abstracts standard intimidating blockchain text arrays into tactile swipe mechanics. It links biometric keychains to intuitive custom gesture patterns, establishing a highly elegant and fail-safe security protocol.'
  }
];

interface ProjectsViewProps {
  onBackToHome: () => void;
  onOpenModal: (modal: 'pitch' | 'hello') => void;
}

export function ProjectsView({ onBackToHome, onOpenModal }: ProjectsViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Interaction' | 'SaaS Systems' | 'Mobile Apps'>('All');
  const [activeProject, setActiveProject] = useState<Project | null>(null);

  const [likedProjects, setLikedProjects] = useState<Record<string, boolean>>({});
  const [bookmarkedProjects, setBookmarkedProjects] = useState<Record<string, boolean>>({});
  const [showAll, setShowAll] = useState(false);

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedProjects(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedProjects(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Active Project Simulators states
  const [auraBg, setAuraBg] = useState<'midnight' | 'solar' | 'aurora'>('midnight');
  const [auraWindows, setAuraWindows] = useState([
    { id: 1, title: 'Studio terminal', x: 20, y: 30, active: true },
    { id: 2, title: 'System metrics', x: 140, y: 90, active: false }
  ]);
  const [kinectaMultiplier, setKinectaMultiplier] = useState(1.0);
  const [kinectaData, setKinectaData] = useState([45, 62, 55, 78, 65, 84, 91]);
  
  // Spring Interactive Sandbox state
  const [springWeight, setSpringWeight] = useState(120);
  const [springStiffness, setSpringStiffness] = useState(0.35);
  const [isPulling, setIsPulling] = useState(false);
  const [pullOffset, setPullOffset] = useState(0);

  // Vapor Customizer state
  const [carColor, setCarColor] = useState<'midnight' | 'gold' | 'cobalt'>('midnight');

  // Nidus Gesture unlock state
  const [unlocked, setUnlocked] = useState(false);
  const [connectingPoints, setConnectingPoints] = useState<number[]>([]);
  const [gestureStatus, setGestureStatus] = useState<'idle' | 'failed' | 'success'>('idle');

  // New states for Zenith CRM / Vehix, Nova Ring, and Chronos Dial
  const [zenithTab, setZenithTab] = useState<'revenue' | 'volume' | 'retention'>('revenue');
  const [zenithChartData, setZenithChartData] = useState<number[]>([12400, 14200, 13100, 18400, 16900, 22100, 20450]);
  const [vehixCardImageIdx, setVehixCardImageIdx] = useState(0);
  const [vehixSimTab, setVehixSimTab] = useState<'screens' | 'metrics'>('screens');
  const [vehixActiveImgIdx, setVehixActiveImgIdx] = useState(0);
  const [hoveredHotspot, setHoveredHotspot] = useState<string | null>(null);
  const [pulseRate, setPulseRate] = useState(72);
  const [stepsCount, setStepsCount] = useState(6420);
  const [ringActive, setRingActive] = useState(true);
  const [dialMinutes, setDialMinutes] = useState(25);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerLeft, setTimerLeft] = useState(1500); // 25 * 60

  // Flexana Breathing Guide states
  const [breathingTrack, setBreathingTrack] = useState<'calm' | 'energize' | 'deep'>('calm');
  const [breathingState, setBreathingState] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Rest'>('Inhale');
  const [breathingSeconds, setBreathingSeconds] = useState(0);
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [breathScale, setBreathScale] = useState(1.0);

  // Reset interactive simulations when active project shifts
  useEffect(() => {
    setUnlocked(false);
    setConnectingPoints([]);
    setGestureStatus('idle');
    setPullOffset(0);
    setCarColor('midnight');
    setAuraBg('midnight');
    setZenithTab('revenue');
    setZenithChartData([12400, 14200, 13100, 18400, 16900, 22100, 20450]);
    setVehixSimTab('screens');
    setVehixActiveImgIdx(0);
    setHoveredHotspot(null);
    setPulseRate(72);
    setStepsCount(6420);
    setRingActive(true);
    setDialMinutes(25);
    setTimerRunning(false);
    setTimerLeft(1500);
    setBreathingTrack('calm');
    setBreathingState('Inhale');
    setBreathingSeconds(0);
    setIsBreathingActive(false);
    setBreathScale(1.0);
    
    // Scroll to top of window smoothly when transitioning to a detailed view or back to list
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeProject]);

  // Flexana Breathing Loop effect
  useEffect(() => {
    if (!isBreathingActive) {
      setBreathScale(1.0);
      setBreathingSeconds(0);
      setBreathingState('Inhale');
      return;
    }

    const interval = setInterval(() => {
      setBreathingSeconds((prevSec) => {
        let nextSec = prevSec + 1;
        
        if (breathingTrack === 'calm') {
          // Box breathing: 4s Inhale, 4s Hold, 4s Exhale, 4s Rest
          if (nextSec <= 4) {
            setBreathingState('Inhale');
            setBreathScale(1.0 + (nextSec / 4) * 0.8);
          } else if (nextSec <= 8) {
            setBreathingState('Hold');
            setBreathScale(1.8);
          } else if (nextSec <= 12) {
            setBreathingState('Exhale');
            setBreathScale(1.8 - ((nextSec - 8) / 4) * 0.8);
          } else if (nextSec <= 16) {
            setBreathingState('Rest');
            setBreathScale(1.0);
          } else {
            nextSec = 1;
            setBreathingState('Inhale');
            setBreathScale(1.0 + (1 / 4) * 0.8);
          }
        } else if (breathingTrack === 'energize') {
          // Bellows: 2s Inhale, 2s Exhale
          if (nextSec <= 2) {
            setBreathingState('Inhale');
            setBreathScale(1.0 + (nextSec / 2) * 0.6);
          } else if (nextSec <= 4) {
            setBreathingState('Exhale');
            setBreathScale(1.6 - ((nextSec - 2) / 2) * 0.6);
          } else {
            nextSec = 1;
            setBreathingState('Inhale');
            setBreathScale(1.0 + (1 / 2) * 0.6);
          }
        } else {
          // 4-7-8 Deep Rest
          if (nextSec <= 4) {
            setBreathingState('Inhale');
            setBreathScale(1.0 + (nextSec / 4) * 0.8);
          } else if (nextSec <= 11) {
            setBreathingState('Hold');
            setBreathScale(1.8);
          } else if (nextSec <= 19) {
            setBreathingState('Exhale');
            setBreathScale(1.8 - ((nextSec - 11) / 8) * 0.8);
          } else {
            nextSec = 1;
            setBreathingState('Inhale');
            setBreathScale(1.0 + (1 / 4) * 0.8);
          }
        }

        // Tactile sound effect when state triggers
        if (nextSec === 1 || 
           (breathingTrack === 'calm' && (nextSec === 5 || nextSec === 9 || nextSec === 13)) || 
           (breathingTrack === 'energize' && nextSec === 3) || 
           (breathingTrack === 'deep' && (nextSec === 5 || nextSec === 12))) {
          try {
            const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioContextClass) {
              const ctx = new AudioContextClass();
              const osc = ctx.createOscillator();
              const gain = ctx.createGain();
              osc.connect(gain);
              gain.connect(ctx.destination);
              
              osc.frequency.setValueAtTime(400, ctx.currentTime);
              gain.gain.setValueAtTime(0.015, ctx.currentTime);
              gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
              osc.start();
              osc.stop(ctx.currentTime + 0.6);
            }
          } catch (e) {}
        }

        return nextSec;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isBreathingActive, breathingTrack]);

  // Nova Ring pulse simulator
  useEffect(() => {
    if (!ringActive) return;
    const interval = setInterval(() => {
      setPulseRate((prev) => {
        const offset = Math.floor((Math.random() - 0.5) * 6);
        return Math.max(62, Math.min(108, prev + offset));
      });
      setStepsCount((prev) => prev + Math.floor(Math.random() * 2));
    }, 1200);
    return () => clearInterval(interval);
  }, [ringActive]);

  // Chronos Focus Timer ticker
  useEffect(() => {
    if (!timerRunning) return;
    const interval = setInterval(() => {
      setTimerLeft((prev) => {
        if (prev <= 1) {
          setTimerRunning(false);
          try {
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.setValueAtTime(880, ctx.currentTime);
            gain.gain.setValueAtTime(0.08, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
            osc.start();
            osc.stop(ctx.currentTime + 1.2);
          } catch (e) {}
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [timerRunning]);

  const handleZenithTabChange = (tab: 'revenue' | 'volume' | 'retention') => {
    setZenithTab(tab);
    if (tab === 'revenue') {
      setZenithChartData([12400, 14200, 13100, 18400, 16900, 22100, 20450]);
    } else if (tab === 'volume') {
      setZenithChartData([320, 410, 390, 580, 510, 690, 640]);
    } else {
      setZenithChartData([88, 91, 89, 93, 92, 95, 94]);
    }
  };

  const handleDialClick = (amount: number) => {
    if (timerRunning) return;
    const nextMin = Math.max(5, Math.min(120, dialMinutes + amount));
    setDialMinutes(nextMin);
    setTimerLeft(nextMin * 60);

    // Play tactile click sound synth
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      gain.gain.setValueAtTime(0.03, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } catch (e) {}
  };

  const filteredProjects = PROJECTS_DATA.filter(
    (p) => selectedCategory === 'All' || p.category === selectedCategory
  );

  const displayedProjects = showAll ? filteredProjects : filteredProjects.slice(0, 4);

  // Kinecta live tick
  useEffect(() => {
    const interval = setInterval(() => {
      setKinectaData((prev) => {
        const next = [...prev.slice(1)];
        const newVal = Math.max(20, Math.min(100, Math.floor(prev[prev.length - 1] + (Math.random() - 0.5) * 15 * kinectaMultiplier)));
        return [...next, newVal];
      });
    }, 1200);
    return () => clearInterval(interval);
  }, [kinectaMultiplier]);

  // Spring organic physics loop
  useEffect(() => {
    if (isPulling) return;
    if (pullOffset === 0) return;

    let id: number;
    let velocity = 0;
    let current = pullOffset;

    const tick = () => {
      const springForce = -springStiffness * current;
      const dampingForce = -0.12 * velocity;
      const acceleration = (springForce + dampingForce) / (springWeight / 100);
      velocity += acceleration;
      current += velocity;

      if (Math.abs(current) < 0.2 && Math.abs(velocity) < 0.2) {
        setPullOffset(0);
      } else {
        setPullOffset(current);
        id = requestAnimationFrame(tick);
      }
    };

    id = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(id);
  }, [isPulling, springStiffness, springWeight]);

  const handlePointClick = (id: number) => {
    if (connectingPoints.includes(id)) return;
    const nextPoints = [...connectingPoints, id];
    setConnectingPoints(nextPoints);

    // Correct unlock pattern: 1 -> 2 -> 3 -> 6
    const correctPattern = [1, 2, 3, 6];
    if (nextPoints.length === correctPattern.length) {
      const isCorrect = nextPoints.every((val, index) => val === correctPattern[index]);
      if (isCorrect) {
        setGestureStatus('success');
        setUnlocked(true);
      } else {
        setGestureStatus('failed');
        setTimeout(() => {
          setConnectingPoints([]);
          setGestureStatus('idle');
        }, 1000);
      }
    }
  };

  return (
    <div 
      className="min-h-screen bg-black text-white tracking-[-0.02em] relative overflow-hidden" 
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      
      {/* Background artwork */}
      <div className="fixed inset-0 pointer-events-none z-10">
        <div 
          className="absolute inset-0 bg-center bg-cover bg-no-repeat" 
          style={{ backgroundImage: `url(${BG_IMAGE_1})` }}
        />
      </div>

      {/* Main Content Area */}
      <div className="relative z-20 min-h-screen overflow-y-auto pt-28 pb-20">
        <div className="max-w-5xl w-full mx-auto px-5 sm:px-8 md:px-10 flex flex-col gap-10">
          
          {!activeProject ? (
            <>
              {/* Top Header Row */}
          <div className="flex flex-col gap-4 animate-fade-in-up">
            <button 
              onClick={onBackToHome}
              className="group flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 hover:text-white transition-colors w-fit cursor-pointer bg-transparent border-none p-0 focus:outline-none"
            >
              <span className="group-hover:-translate-x-1 transition-transform">←</span>
              <span>Back to Home</span>
            </button>
            
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-5">
              <div>
                <span className="font-mono text-xs text-white/40 tracking-widest uppercase">CASE STUDIES</span>
                <h1 
                  className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-white leading-[1.15] mt-1"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  Selected Works
                </h1>
              </div>

              {/* Categories selector */}
              <div className="flex items-center gap-1.5 bg-white/[0.04] border border-white/5 p-1 rounded-full w-full sm:w-fit overflow-x-auto scrollbar-none whitespace-nowrap max-w-full">
                {(['All', 'Interaction', 'SaaS Systems', 'Mobile Apps'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-1.5 rounded-full text-xs font-medium tracking-tight cursor-pointer transition-all duration-300 shrink-0 ${
                      selectedCategory === cat 
                        ? 'bg-white text-black font-semibold' 
                        : 'text-white/60 hover:text-white hover:bg-white/[0.02]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Projects grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {displayedProjects.map((project) => {
              const isLiked = likedProjects[project.id];
              const isBookmarked = bookmarkedProjects[project.id];

              return (
                <div
                  key={project.id}
                  onClick={() => setActiveProject(project)}
                  className="border border-white/10 bg-black/20 backdrop-blur-[3px] rounded-3xl overflow-hidden hover:border-white/25 hover:bg-black/30 transition-all duration-300 group cursor-pointer flex flex-col justify-between min-h-[380px] sm:min-h-[420px]"
                >
                  {/* Top content */}
                  <div className="relative overflow-hidden h-[180px] sm:h-[220px] w-full border-b border-white/5 bg-neutral-900/40">
                    {project.image.includes('.mp4') || project.image.includes('.m3u8') ? (
                      <VideoPlayer 
                        src={project.image}
                        className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                      />
                    ) : (
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="absolute inset-0 w-full h-full object-cover object-top opacity-80 group-hover:opacity-100 group-hover:scale-[1.03] grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                        referrerPolicy="no-referrer"
                      />
                    )}
                    <div className="absolute top-4 left-4 flex gap-2">
                      <span className="font-mono text-[9px] font-semibold tracking-wider bg-black/60 text-white/90 px-2.5 py-1 rounded-full uppercase border border-white/10 backdrop-blur-md">
                        {project.tag}
                      </span>
                    </div>
                    <div className="absolute top-4 right-4 flex gap-2 z-30">
                      <button 
                        onClick={(e) => toggleLike(project.id, e)}
                        className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white/80 hover:text-white hover:scale-105 transition-all focus:outline-none"
                      >
                        <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-red-500 text-red-500' : 'text-white/80'}`} />
                      </button>
                      <button 
                        onClick={(e) => toggleBookmark(project.id, e)}
                        className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white/80 hover:text-white hover:scale-105 transition-all focus:outline-none"
                      >
                        <Bookmark className={`h-3.5 w-3.5 ${isBookmarked ? 'fill-emerald-400 text-emerald-400' : 'text-white/80'}`} />
                      </button>
                    </div>
                  </div>

                  {/* Text Details */}
                  <div className="p-6 flex-1 flex flex-col justify-between gap-4">
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="text-xl font-bold tracking-tight text-white group-hover:text-white/95">
                          {project.title}
                        </h3>
                        <span className="text-xs font-mono text-white/30 group-hover:text-white/60 transition-colors">
                          {project.year}
                        </span>
                      </div>
                      <p className="text-xs font-medium text-white/40 mt-0.5 uppercase tracking-wide">
                        {project.subtitle}
                      </p>
                      <p className="text-xs sm:text-sm text-white/60 leading-relaxed mt-2.5 line-clamp-3">
                        {project.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-white/5">
                      <div className="flex flex-wrap gap-1.5">
                        {project.tech.slice(0, 3).map((t) => (
                          <span key={t} className="text-[10px] font-mono text-white/50 bg-white/5 px-2 py-0.5 rounded-md">
                            {t}
                          </span>
                        ))}
                      </div>
                      <span className="text-xs text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all flex items-center gap-1 font-semibold">
                        View Sandbox <span>→</span>
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Optional Show All toggle to preserve clean 2x2 presentation */}
          {filteredProjects.length > 4 && (
            <div className="flex justify-center mt-2">
              <button
                onClick={() => setShowAll(!showAll)}
                className="flex items-center gap-2 bg-white/[0.04] hover:bg-white/10 border border-white/10 text-white font-medium text-xs px-6 py-3 rounded-full transition-all duration-300 cursor-pointer hover:scale-[1.02] active:scale-95"
              >
                <span>{showAll ? 'Show 2x2 Layout' : `View All (${filteredProjects.length}) Projects`}</span>
                <span className="font-mono">{showAll ? '↑' : '↓'}</span>
              </button>
            </div>
          )}

          {/* Showcase bottom panel */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-black/20 border border-white/10 p-6 rounded-3xl backdrop-blur-[3px]">
            <div className="max-w-md">
              <span className="font-mono text-[10px] text-white/40 tracking-widest uppercase">LAB PROTOTYPING</span>
              <h3 className="text-lg font-bold text-white mt-1">Want to design custom interactive systems?</h3>
              <p className="text-xs text-white/50 mt-1 leading-relaxed">
                We design fully custom high-fidelity simulators for startups so founders can test human factors before writing core code.
              </p>
            </div>
            <button
              onClick={() => onOpenModal('pitch')}
              className="bg-white text-black font-semibold text-sm px-6 py-3 rounded-full hover:bg-neutral-200 transition-colors cursor-pointer w-full md:w-auto text-center"
            >
              Pitch us an Idea
            </button>
          </div>
            </>
          ) : (
            <div className="flex flex-col gap-6 animate-fade-in-up">
              
              {/* Back button */}
              <div className="flex items-center">
                <button 
                  onClick={() => setActiveProject(null)}
                  className="group flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 hover:text-white transition-colors w-fit cursor-pointer bg-transparent border-none p-0 focus:outline-none"
                >
                  <span className="group-hover:-translate-x-1 transition-transform">←</span>
                  <span>Back to Selected Works</span>
                </button>
              </div>

              {/* Seamless Two-Column Showcase Layout */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-start mt-2">
                
                {/* Left Column: Project Overview & Details */}
                <div className="md:col-span-5 flex flex-col gap-6">
                  <div className="flex flex-col gap-4">
                    <span className="text-[10px] font-mono tracking-widest text-white/50 uppercase bg-white/5 px-3 py-1 rounded-full border border-white/5 w-fit">
                      {activeProject.category}
                    </span>
                    <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white mt-1">
                      {activeProject.title}
                    </h1>
                    <p className="text-xs font-mono uppercase tracking-wider text-white/40 -mt-2">
                      {activeProject.subtitle}
                    </p>
                    
                    <p className="text-sm text-white/70 leading-relaxed font-light mt-2">
                      {activeProject.details || activeProject.description}
                    </p>

                    <div className="flex flex-col gap-3.5 mt-2 pt-5 border-t border-white/5">
                      <div className="flex flex-col">
                        <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest">My Role</span>
                        <span className="text-xs sm:text-sm text-white/90 font-medium mt-0.5">{activeProject.role}</span>
                      </div>
                      <div className="flex justify-between items-center mt-1">
                        <div className="flex flex-col">
                          <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest">Launch Year</span>
                          <span className="text-xs text-white/90 font-mono font-medium mt-0.5">{activeProject.year}</span>
                        </div>
                        <div className="flex flex-col text-right">
                          <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest">Fidelity Level</span>
                          <span className="text-xs text-white/90 font-medium flex items-center justify-end gap-1 mt-0.5">
                            <Sparkles className="w-3.5 h-3.5 text-white/70" /> High-Fidelity
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Tech & Contact */}
                  <div className="flex flex-col gap-4 pt-4 border-t border-white/5">
                    <div className="flex flex-wrap gap-1.5">
                      {activeProject.tech.map((t) => (
                        <span key={t} className="text-[10px] font-mono text-white/60 bg-white/5 border border-white/5 px-2.5 py-1 rounded-full">
                          {t}
                        </span>
                      ))}
                    </div>
                    
                    <button 
                      onClick={() => { onOpenModal('pitch'); }}
                      className="flex items-center justify-center gap-2 bg-white text-black font-semibold text-xs py-3 rounded-full hover:bg-neutral-200 transition-all w-full cursor-pointer hover:scale-[1.01] active:scale-95 duration-200"
                    >
                      <span>Pitch standard system integration</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Right Column: Full-Width High-Fidelity Slider */}
                <div className="md:col-span-7 flex flex-col gap-4 animate-fade-in">
                  
                  {/* Aspect-Ratio Image Viewer */}
                  <div className="relative w-full aspect-[4/3] bg-[#070707] rounded-[24px] sm:rounded-[32px] overflow-hidden border border-white/10 shadow-2xl flex items-center justify-center group">
                    
                    {/* Ambient glow in the background based on active slide */}
                    <div 
                      className="absolute inset-0 bg-cover bg-center opacity-[0.05] scale-110 filter blur-2xl pointer-events-none transition-all duration-700"
                      style={{ 
                        backgroundImage: `url(${(activeProject.images && activeProject.images[vehixActiveImgIdx]) || activeProject.image})` 
                      }}
                    />

                    {/* Image/Video Slide Sequence */}
                    {(activeProject.images || [activeProject.image]).map((imgUrl, idx) => {
                      const isVideo = imgUrl.includes('.mp4') || imgUrl.includes('.m3u8');
                      if (isVideo) {
                        return (
                          <VideoPlayer 
                            key={idx}
                            src={imgUrl}
                            className={`absolute inset-0 w-full h-full object-cover object-top grayscale hover:grayscale-0 group-hover:grayscale-0 hover:scale-[1.01] transition-all duration-700 ease-out select-none ${
                              vehixActiveImgIdx === idx 
                                ? 'opacity-100 scale-100 pointer-events-auto' 
                                : 'opacity-0 scale-95 pointer-events-none'
                            }`}
                          />
                        );
                      }
                      return (
                        <img 
                          key={idx}
                          src={imgUrl} 
                          alt={`${activeProject.title} - Showcase View ${idx + 1}`}
                          className={`absolute inset-0 w-full h-full object-cover object-top grayscale hover:grayscale-0 group-hover:grayscale-0 hover:scale-[1.01] transition-all duration-700 ease-out select-none ${
                            vehixActiveImgIdx === idx 
                              ? 'opacity-100 scale-100 pointer-events-auto' 
                              : 'opacity-0 scale-95 pointer-events-none'
                          }`}
                          referrerPolicy="no-referrer"
                        />
                      );
                    })}

                    {/* Subtle bottom gradient shadow */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent pointer-events-none" />
                  </div>

                  {/* Navigation Control Bar below the slider */}
                  <div className="flex items-center justify-between px-2 mt-1">
                    
                    {/* Fraction and dots pagination */}
                    <div className="flex items-center gap-4">
                      <span className="font-mono text-xs sm:text-sm text-white/50 tracking-widest">
                        {String(vehixActiveImgIdx + 1).padStart(2, '0')} <span className="text-white/20">/</span> {String((activeProject.images || [activeProject.image]).length).padStart(2, '0')}
                      </span>
                      
                      {/* Dots indicators */}
                      <div className="flex items-center gap-1.5">
                        {(activeProject.images || [activeProject.image]).map((_, idx) => (
                          <button
                            key={idx}
                            onClick={() => setVehixActiveImgIdx(idx)}
                            className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                              vehixActiveImgIdx === idx 
                                ? 'bg-white w-4' 
                                : 'bg-white/20 hover:bg-white/50 w-1.5'
                            }`}
                            aria-label={`Go to image slide ${idx + 1}`}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Sliding arrows placed next to each other */}
                    <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full p-0.5">
                      <button
                        onClick={() => {
                          const len = (activeProject.images || [activeProject.image]).length;
                          setVehixActiveImgIdx((prev) => (prev - 1 + len) % len);
                        }}
                        className="w-9 h-9 rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200 cursor-pointer active:scale-90"
                        title="Previous Image"
                      >
                        ←
                      </button>
                      <button
                        onClick={() => {
                          const len = (activeProject.images || [activeProject.image]).length;
                          setVehixActiveImgIdx((prev) => (prev + 1) % len);
                        }}
                        className="w-9 h-9 rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200 cursor-pointer active:scale-90"
                        title="Next Image"
                      >
                        →
                      </button>
                    </div>

                  </div>

                </div>

              </div>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
