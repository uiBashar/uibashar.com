import React, { useState, useEffect, useRef } from 'react';
import Hls from 'hls.js';
import { ArrowLeft, Sparkles, GraduationCap, BookOpen, CheckCircle2, ArrowRight, Layers, Cpu, Shield, Clock, Heart, Bookmark } from 'lucide-react';

const BG_IMAGE_1 = "https://github.com/uiBashar/uibashar.com/blob/main/bg1.jpg?raw=true";

interface Course {
  id: string;
  title: string;
  subtitle: string;
  tag: string;
  status: string;
  description: string;
  image: string;
  curriculum: string[];
  duration: string;
  intensity: string;
  role: string;
  details: string;
  modules: {
    title: string;
    description: string;
    topics: string[];
  }[];
  bonus?: string[];
  outcomes?: string[];
}

interface VideoPlayerProps {
  src: string;
  className?: string;
  autoPlay?: boolean;
  loop?: boolean;
  muted?: boolean;
  playsInline?: boolean;
  key?: React.Key;
}

export function VideoPlayer({
  src,
  className,
  autoPlay = true,
  loop = true,
  muted = true,
  playsInline = true,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let hls: Hls | null = null;

    if (src.includes('.m3u8')) {
      if (Hls.isSupported()) {
        hls = new Hls({
          maxMaxBufferLength: 10,
          enableWorker: true,
        });
        hls.loadSource(src);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (autoPlay) {
            video.play().catch(err => console.log("Autoplay blocked/interrupted:", err));
          }
        });
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        // Native Safari HLS support
        video.src = src;
      }
    } else {
      // Standard video
      video.src = src;
    }

    return () => {
      if (hls) {
        hls.destroy();
      }
    };
  }, [src, autoPlay]);

  return (
    <video
      ref={videoRef}
      className={className}
      autoPlay={autoPlay}
      loop={loop}
      muted={muted}
      playsInline={playsInline}
    />
  );
}

const COURSES_DATA: Course[] = [
  {
    id: 'ui-design-fundamentals',
    title: 'UI Design Fundamentals',
    subtitle: 'Design Interfaces That People Love',
    tag: 'FOUNDATIONS COURSE',
    status: 'ENROLLING',
    description: 'Go from blank screens to polished, portfolio-worthy UI through a real client-style project.',
    image: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260324_024928_1efd0b0d-6c02-45a8-8847-1030900c4f63.mp4',
    curriculum: ['Figma Mastery', 'Visual Systems', 'Design Tokens', 'Client Project', 'Portfolio Case Studies'],
    duration: '10 Weeks',
    intensity: 'Beginner to Intermediate',
    role: 'Lead Mentor: uiBashar',
    details: 'This professional, practical, portfolio-driven foundations course is structured like a premium bootcamp. Go from blank screens to polished, portfolio-ready UI by solving real client-style briefs. Master typographic hierarchies, 8pt spatial grid mechanics, responsive design rules, atomic design systems, and developer handoff workflows.',
    modules: [
      {
        title: 'Module 01 — Understanding UI Design',
        description: 'Establish the foundational context of modern interface design and product assembly.',
        topics: [
          'What UI Design Really Is',
          'UI vs UX',
          'The Product Design Process',
          'How Great Interfaces Are Built',
          'Analyzing Real-World Apps'
        ]
      },
      {
        title: 'Module 02 — Design Foundations',
        description: 'Master core layout mechanics, contrast ratios, and spatial balance rules.',
        topics: [
          'Typography Fundamentals',
          'Color Theory',
          'Visual Hierarchy',
          'White Space',
          'Layout Principles',
          'Alignment & Spacing'
        ]
      },
      {
        title: 'Module 03 — Figma Essentials',
        description: 'Gain full creative speed and technical proficiency inside standard canvas interfaces.',
        topics: [
          'Figma Interface & Shortcuts',
          'Frames, Nested Layouts & Constraints',
          'Auto Layout Deep Dive',
          'Components, Variants & Interactive Properties',
          'Variables & Styles',
          'Design Libraries & Shared Workspaces'
        ]
      },
      {
        title: 'Module 04 — Building a Design System',
        description: 'Construct a reusable, scalable token system and atomic component library.',
        topics: [
          'Design Tokens & Token Naming Systems',
          'Color System & Gray Ramp Generation',
          'Typography Scale & Fluid Sizing',
          '8pt Grid System & Row Heights',
          'Icon Libraries & Grid Alignments',
          'Button Variants, Input Fields & Interactive Cards',
          'Navigation Components & Shell Scaffolds'
        ]
      },
      {
        title: 'Module 05 — Mobile UI Design',
        description: 'Create responsive mobile structures adhering to strict OS guidelines.',
        topics: [
          'Mobile Design Guidelines & Safe Zones',
          'iOS vs Android Native Patterns',
          'Responsive App Layouts & Breakpoints',
          'Designing a Complete Mobile App Flow'
        ]
      },
      {
        title: 'Module 06 — Web UI Design',
        description: 'Structure complex web grids, dashboards, and responsive marketing landing grids.',
        topics: [
          'Desktop Grid Systems & Flexbox Skeletons',
          'Landing Page Structures & Eye Tracking',
          'Multi-pane SaaS Dashboard Layouts',
          'Responsive Desktop-to-Tablet Design',
          'Sections, Heros & Form Configurations'
        ]
      },
      {
        title: 'Module 07 — Advanced UI Techniques',
        description: 'Elevate your aesthetic polish and modern interface details.',
        topics: [
          'Glassmorphism & Depth Blurring',
          'Modern Minimalism & High Contrast Slate Themes',
          'Visual Balance & Optical Spacing Correction',
          'Premium UI Details & Spatial Layering',
          'Micro Interactions (Design Perspective)'
        ]
      },
      {
        title: 'Module 08 — Real Client Project',
        description: 'Apply learning-by-building. Design a complete product from scratch.',
        topics: [
          'Selecting a Brief: SaaS Dashboard / Finance / AI Product / Healthcare App',
          'Conducting Product Research & Competitive Audits',
          'Constructing Low-Fidelity Wireframes & Skeleton Structures',
          'Crafting High-Fidelity Responsive User Interfaces',
          'Assembling Interactive Prototypes & Interactive Micro-flows'
        ]
      },
      {
        title: 'Module 09 — Portfolio & Presentation',
        description: 'Present your completed product case studies beautifully for product leads.',
        topics: [
          'Presenting Your Work Objectively & Confidently',
          'Case Study Basics, Storytelling & Layout Structure',
          'Designing a Clean Personal Portfolio Structure',
          'Behance & Dribbble Creative Presentation Layouts',
          'Exporting Assets & Developer Documentation Specs'
        ]
      },
      {
        title: 'Module 10 — Professional Workflow',
        description: 'Bridge the design-to-development pipeline with seamless naming and communication.',
        topics: [
          'Working Collaboratively with Frontend Developers',
          'Handoff Best Practices, Inspection & Specs',
          'File Organizing & Component Naming Conventions',
          'Team Collaborations & Figma Version History control'
        ]
      }
    ],
    bonus: [
      'UI Design Checklist & Spacing Reference Card',
      'Premium Custom Figma Resource Packs',
      'Atomic Design System Starter Kit',
      'Handcrafted Clean Icon Library',
      'Selected Display Font Collection',
      'Exclusive Color Palette Collections',
      'Case Study & Portfolio Slide Templates',
      'Lifetime Mentor Community Access',
      'Weekly Project Review & Critique Sessions',
      'Official Certificate of Completion'
    ],
    outcomes: [
      'A complete, portfolio-ready UI design project',
      'A reusable, tokenized atomic design system',
      'Strong Figma mastery & industry workflow skills',
      'A polished case study ready for review',
      'Confidence to take on freelance and client projects',
      'A solid foundation to expand into UX and Product Design'
    ]
  },
  {
    id: 'ux-design-decisions',
    title: 'UX Design & Product Decision-Making',
    subtitle: 'Think Like a Senior UX Designer',
    tag: 'STRATEGY WORKSHOP',
    status: 'AVAILABLE',
    description: 'Learn the mindset behind every great product decision—not just how to make beautiful screens.',
    image: 'https://stream.mux.com/4IMYGcL01xjs7ek5ANO17JC4VQVUTsojZlnw4fXzwSxc.m3u8',
    curriculum: ['UX Strategy', 'User Research', 'Information Architecture', 'Usability Testing', 'Product Decision-Making'],
    duration: '8 Weeks',
    intensity: 'Intermediate to Advanced',
    role: 'Lead Instructor: uiBashar',
    details: 'Learn how great designers make product decisions that improve user experience and business outcomes. This comprehensive course covers the entire UX workflow—from foundational research and empathy mappings to wireframing, heuristic testing, and presenting a professional, portfolio-ready UX case study.',
    modules: [
      {
        title: 'Module 01 — UX Foundations',
        description: 'Understand the underlying principles of user experience and product design thinking.',
        topics: [
          'What is UX Design?',
          'UX vs UI',
          'Human-Centered Design',
          'Design Thinking',
          'Product Thinking'
        ]
      },
      {
        title: 'Module 02 — UX Research',
        description: 'Gather actionable user insights and learn to run rigorous competitive research audits.',
        topics: [
          'User Interviews & Qualitative Questions',
          'Survey Design & Quantitative Metrics',
          'Competitive Analysis & Market Positioning',
          'Heuristic Evaluation Foundations',
          'Research Synthesis & Insight Extraction'
        ]
      },
      {
        title: 'Module 03 — Understanding Users',
        description: 'Translate user findings into precise user profiles, pathways, and mental models.',
        topics: [
          'User Personas & Target Demographics',
          'Empathy Mapping & User Sentiments',
          'User Journey Mapping & Multi-stage Flows',
          'Jobs-to-Be-Done (JTBD) Frameworks',
          'Identifying Friction, Pain Points & User Goals'
        ]
      },
      {
        title: 'Module 04 — Information Architecture',
        description: 'Organize complex system content structures for fluid, intuitive navigation.',
        topics: [
          'Site Maps & Navigation Trees',
          'User Flows & Branching Pathways',
          'Task Flows & Direct Conversions',
          'Navigation Design & Click Density',
          'Content Organization & Card Sorting'
        ]
      },
      {
        title: 'Module 05 — Wireframing & Prototyping',
        description: 'Iterate quickly using functional screen skeletons before visual layers.',
        topics: [
          'Low-Fidelity Hand Wireframes & Concepts',
          'Mid-Fidelity Wireframes in Figma',
          'Interactive Interactive Prototypes',
          'Rapid Iteration & Screen Transitions'
        ]
      },
      {
        title: 'Module 06 — Product Decision-Making',
        description: 'Balance user pain points with engineering scope and business requirements.',
        topics: [
          'Problem Framing & Goal Defining',
          'Feature Prioritization Frameworks (RICE/Kano)',
          'MVP (Minimum Viable Product) vs Full Feature Suite',
          'Balancing User Desires & Business Needs',
          'Data-Informed Design Decisions & A/B testing'
        ]
      },
      {
        title: 'Module 07 — Usability Testing',
        description: 'Validate your structural screens through real user observation and testing.',
        topics: [
          'Planning User Tests & Scriptwriting',
          'Conducting Usability Tests & Moderation',
          'Identifying Cognitive Friction & UX Blocks',
          'Iterating Layouts Based on Observed Usability Feedback'
        ]
      },
      {
        title: 'Module 08 — Real-World UX Case Study',
        description: 'Solve a real-world product challenge and document the entire decision process.',
        topics: [
          'Solve a Real-World Product Challenge',
          'Documenting Your Hypothesis & Solutions',
          'Presenting a Professional UX Case Study Deck',
          'Portfolio Best Practices for UX Hiring Managers'
        ]
      }
    ],
    bonus: [
      'Comprehensive UX Research Templates & Guides',
      'Figma User Persona & Customer Journey Map Templates',
      'Step-by-Step Usability Audit Checklist',
      'AI Productivity Tools for Fast UX Workflows',
      'Official Professional Certificate of Completion'
    ],
    outcomes: [
      'A complete, high-fidelity portfolio-ready UX case study',
      'Durable frameworks to justify your design decisions to stakeholders',
      'Mastery over industry standard user research and testing methods',
      'Improved product intuition to confidently build MVPs and SaaS products'
    ]
  },
  {
    id: 'design-audit-mentorship',
    title: '1-on-1 Design Audit & Career Mentorship',
    subtitle: 'Get Honest Feedback. Grow Faster.',
    tag: 'PRIVATE MENTORSHIP',
    status: 'CUSTOM PACE',
    description: 'Discover what\'s holding your designs back with personalized reviews and one-on-one mentorship.',
    image: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260402_143803_f635b644-d959-4f16-9d29-cedaeb5c6de0.mp4',
    curriculum: ['Portfolio Review', 'UI/UX Feedback', 'Project Mentorship', 'Professional Workflow', 'Career Growth'],
    duration: 'Ongoing',
    intensity: 'All Skill Levels',
    role: 'Lead Mentor: uiBashar',
    details: 'Personalized guidance to improve your design skills, portfolio, and career. Get honest, pixel-level feedback, deep architectural UX auditing, and professional mentorship to advance your design journey.',
    modules: [
      {
        title: 'Module 01 — Portfolio & Skill Review',
        description: 'Audit your existing work, evaluate core competencies, and outline a custom skill roadmap.',
        topics: [
          'Portfolio Audit',
          'Skill Assessment',
          'Personalized Growth Plan'
        ]
      },
      {
        title: 'Module 02 — UI/UX Design Feedback',
        description: 'Deep-dive critique sessions on your layout spacing, alignment, and product thinking.',
        topics: [
          'UI Design Review',
          'UX Analysis',
          'Product Thinking',
          'Actionable Improvements'
        ]
      },
      {
        title: 'Module 03 — Real Project Mentorship',
        description: 'Collaborate live or asynchronously to solve real layout, navigation, and prototype blockers.',
        topics: [
          'Live Design Reviews',
          'Project Guidance',
          'Problem Solving',
          'Design Iterations'
        ]
      },
      {
        title: 'Module 04 — Professional Workflow',
        description: 'Optimize your design pipeline, component architecture, and team collaboration.',
        topics: [
          'Figma Best Practices',
          'Design Systems',
          'Developer Handoff',
          'Client Communication'
        ]
      },
      {
        title: 'Module 05 — Career Growth',
        description: 'Position your value, build high-converting case studies, and prepare for interviews.',
        topics: [
          'Portfolio Optimization',
          'Case Study Review',
          'Freelancing Tips',
          'Interview Preparation',
          'LinkedIn & Personal Branding'
        ]
      }
    ],
    bonus: [
      'Private 1-on-1 Mentor Support Channel',
      'Exclusive Premium UI/UX Resource Library',
      'Lifetime Access to Private Alumni Community',
      'Official Professional Certificate of Completion'
    ],
    outcomes: [
      'A professionally audited, industry-standard design portfolio',
      'Deeper product thinking to articulate and defend your layout decisions',
      'Figma masterclasses with advanced component systems and handoffs',
      'Clear, actionable career blueprint to land senior or freelance roles'
    ]
  }
];

interface LearnViewProps {
  onBackToHome: () => void;
  onOpenModal: (modal: any) => void;
}

export function LearnView({ onBackToHome, onOpenModal }: LearnViewProps) {
  const [activeCourse, setActiveCourse] = useState<Course | null>(null);
  const [learnForm, setLearnForm] = useState({ name: '', email: '', course: 'motion' });
  const [learnSuccess, setLearnSuccess] = useState(false);

  const [likedCourses, setLikedCourses] = useState<Record<string, boolean>>({});
  const [bookmarkedCourses, setBookmarkedCourses] = useState<Record<string, boolean>>({});

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedCourses(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedCourses(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    setLearnSuccess(true);
  };

  return (
    <div 
      className="min-h-screen bg-black text-white tracking-[-0.02em] relative overflow-hidden" 
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      
      {/* Background artwork */}
      <div className="fixed inset-0 pointer-events-none z-10">
        <div 
          className="absolute inset-0 bg-center bg-cover bg-no-repeat" 
          style={{ backgroundImage: `url(${BG_IMAGE_1})` }}
        />
      </div>

      {/* Main Content Area */}
      <div className="relative z-20 min-h-screen overflow-y-auto pt-28 pb-20">
        <div className="max-w-5xl w-full mx-auto px-5 sm:px-8 md:px-10 flex flex-col gap-10">
          
          {!activeCourse ? (
            <>
              {/* Top Header Row */}
              <div className="flex flex-col gap-4 animate-fade-in-up">
                <button 
                  onClick={onBackToHome}
                  className="group flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 hover:text-white transition-colors w-fit cursor-pointer bg-transparent border-none p-0 focus:outline-none"
                >
                  <span className="group-hover:-translate-x-1 transition-transform">←</span>
                  <span>Back to Home</span>
                </button>
                
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-5">
                  <div>
                    <span className="font-mono text-xs text-white/40 tracking-widest uppercase">EDUCATIONAL PROGRAMS</span>
                    <h1 
                      className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-white leading-[1.15] mt-1"
                      style={{ fontFamily: 'var(--font-heading)' }}
                    >
                      Learn with Me
                    </h1>
                  </div>
                </div>
              </div>

              {/* Grid of Course Cards (2x2 Style) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {COURSES_DATA.map((course) => {
                  const isLiked = likedCourses[course.id];
                  const isBookmarked = bookmarkedCourses[course.id];

                  return (
                    <div
                      key={course.id}
                      onClick={() => {
                        setActiveCourse(course);
                        setLearnForm({ ...learnForm, course: course.id });
                        setLearnSuccess(false);
                      }}
                      className="border border-white/10 bg-black/20 backdrop-blur-[3px] rounded-3xl overflow-hidden hover:border-white/25 hover:bg-black/30 transition-all duration-300 group cursor-pointer flex flex-col justify-between min-h-[380px] sm:min-h-[420px]"
                    >
                      {/* Top content - Image Container */}
                      <div className="relative overflow-hidden h-[180px] sm:h-[220px] w-full border-b border-white/5 bg-neutral-900/40">
                        {course.image.includes('.mp4') || course.image.includes('.m3u8') ? (
                          <VideoPlayer 
                            src={course.image}
                            className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                          />
                        ) : (
                          <img 
                            src={course.image} 
                            alt={course.title}
                            className="absolute inset-0 w-full h-full object-cover object-top opacity-85 group-hover:opacity-100 group-hover:scale-[1.03] grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                            referrerPolicy="no-referrer"
                          />
                        )}
                        <div className="absolute top-4 left-4 flex gap-1.5 z-30">
                          <span className="text-[9px] font-mono font-medium uppercase tracking-wider bg-black/70 backdrop-blur-md text-white border border-white/10 px-2.5 py-1 rounded-full">
                            {course.tag}
                          </span>
                          <span className="text-[9px] font-mono font-semibold uppercase tracking-wider bg-emerald-500/10 backdrop-blur-md text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full">
                            {course.status}
                          </span>
                        </div>
                        <div className="absolute top-4 right-4 flex gap-2 z-30">
                          <button 
                            onClick={(e) => toggleLike(course.id, e)}
                            className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white/80 hover:text-white hover:scale-105 transition-all focus:outline-none"
                          >
                            <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-red-500 text-red-500' : 'text-white/80'}`} />
                          </button>
                          <button 
                            onClick={(e) => toggleBookmark(course.id, e)}
                            className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white/80 hover:text-white hover:scale-105 transition-all focus:outline-none"
                          >
                            <Bookmark className={`h-3.5 w-3.5 ${isBookmarked ? 'fill-emerald-400 text-emerald-400' : 'text-white/80'}`} />
                          </button>
                        </div>
                      </div>

                      {/* Middle description */}
                      <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                        <div className="flex flex-col gap-2">
                          <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-white transition-colors leading-tight">
                            {course.title}
                          </h3>
                          <p className="text-[12px] text-white/50 leading-relaxed line-clamp-2">
                            {course.description}
                          </p>
                        </div>

                        {/* Bottom Tags */}
                        <div className="flex flex-col gap-4">
                          <div className="flex flex-wrap gap-1">
                            {course.curriculum.slice(0, 3).map((item) => (
                              <span 
                                key={item} 
                                className="text-[10px] bg-white/[0.04] text-white/60 border border-white/5 px-2 py-0.5 rounded-full"
                              >
                                {item}
                              </span>
                            ))}
                          </div>
                          <span className="text-xs text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all flex items-center gap-1 font-semibold">
                            Explore Curriculum <span>→</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Showcase bottom panel */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-black/20 border border-white/10 p-6 rounded-3xl backdrop-blur-[3px]">
                <div className="max-w-md">
                  <span className="font-mono text-[10px] text-white/40 tracking-widest uppercase">STAY INSPIRED</span>
                  <h3 className="text-lg font-bold text-white mt-1">Want custom design workshops for your team?</h3>
                  <p className="text-xs text-white/50 mt-1 leading-relaxed">
                    We host deep-dive live team training programs covering responsive design pipelines, modular design systems, and interaction choreography.
                  </p>
                </div>
                <button
                  onClick={() => onOpenModal('pitch')}
                  className="bg-white text-black font-semibold text-sm px-6 py-3 rounded-full hover:bg-neutral-200 transition-colors cursor-pointer w-full md:w-auto text-center border-none focus:outline-none"
                >
                  Contact for Teams
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col gap-6 animate-fade-in-up">
              
              {/* Back button */}
              <div className="flex items-center">
                <button 
                  onClick={() => setActiveCourse(null)}
                  className="group flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 hover:text-white transition-colors w-fit cursor-pointer bg-transparent border-none p-0 focus:outline-none"
                >
                  <span className="group-hover:-translate-x-1 transition-transform">←</span>
                  <span>Back to Programs</span>
                </button>
              </div>

              {/* Seamless Two-Column Showcase Layout */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-start mt-2">
                
                {/* Left Column: Course Overview & Registration */}
                <div className="md:col-span-5 flex flex-col gap-6">
                  {/* Hero Image/Video Preview */}
                  <div className="relative overflow-hidden aspect-video rounded-3xl border border-white/10 bg-neutral-900/50 group cursor-pointer">
                    {activeCourse.image.includes('.mp4') || activeCourse.image.includes('.m3u8') ? (
                      <VideoPlayer 
                        src={activeCourse.image}
                        className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                      />
                    ) : (
                      <img 
                        src={activeCourse.image} 
                        alt={activeCourse.title}
                        className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                        referrerPolicy="no-referrer"
                      />
                    )}
                  </div>

                  <div className="flex flex-col gap-4">
                    <span className="text-[10px] font-mono tracking-widest text-white/50 uppercase bg-white/5 px-3 py-1 rounded-full border border-white/5 w-fit">
                      {activeCourse.tag}
                    </span>
                    <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white mt-1">
                      {activeCourse.title}
                    </h1>
                    <p className="text-xs font-mono uppercase tracking-wider text-white/40 -mt-2">
                      {activeCourse.subtitle}
                    </p>
                    
                    <p className="text-sm text-white/70 leading-relaxed font-light mt-2">
                      {activeCourse.details}
                    </p>
                  </div>

                  {/* Metadata Boxes */}
                  <div className="grid grid-cols-2 gap-3 bg-white/[0.02] border border-white/5 p-4 rounded-2xl">
                    <div className="flex flex-col gap-1">
                      <span className="text-[9px] font-mono uppercase tracking-wider text-white/40">Duration</span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Clock className="h-3.5 w-3.5 text-white/60" strokeWidth={1.5} />
                        <span className="text-xs text-white font-medium">{activeCourse.duration}</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[9px] font-mono uppercase tracking-wider text-white/40">Audience</span>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <GraduationCap className="h-3.5 w-3.5 text-white/60" strokeWidth={1.5} />
                        <span className="text-xs text-white font-medium">{activeCourse.intensity}</span>
                      </div>
                    </div>
                  </div>

                  {/* Request / Enrollment form */}
                  <div className="relative overflow-hidden bg-neutral-950/90 border border-transparent p-6 sm:p-7 rounded-3xl backdrop-blur-md transition-all duration-300 shadow-xl shadow-black/60">
                    {/* Top Accent glow light */}
                    <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-emerald-400/40 to-transparent" />
                    
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <h3 className="text-sm font-bold uppercase tracking-widest text-white">Request Syllabus & Access</h3>
                      <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="text-[9px] font-mono font-semibold text-emerald-400 tracking-wider">SLOTS AVAILABLE</span>
                      </div>
                    </div>
                    
                    <p className="text-[11px] text-white/60 leading-relaxed mb-5">
                      Enter your details below to instantly receive the comprehensive curriculum, class schedule templates, and secure priority mentor slots with <span className="text-white font-medium">uiBashar</span>.
                    </p>

                    {learnSuccess ? (
                      <div className="bg-emerald-500/10 border border-emerald-500/20 p-5 rounded-2xl text-center animate-fade-in-up">
                        <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mx-auto mb-3">
                          <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                        </div>
                        <span className="text-emerald-400 text-sm font-bold block">Syllabus Request Sent!</span>
                        <p className="text-[11px] text-white/50 mt-1 leading-relaxed">
                          We've dispatched the official program files to <span className="text-white font-medium">{learnForm.email}</span>. Please verify your inbox and spam folder shortly.
                        </p>
                      </div>
                    ) : (
                      <form onSubmit={handleApply} className="flex flex-col gap-4">
                        <div className="relative group/input">
                          <label className="block text-[10px] font-mono font-bold uppercase tracking-widest text-white/50 mb-1.5 group-focus-within/input:text-white transition-colors">
                            Your Professional Name
                          </label>
                          <input 
                            type="text" 
                            required 
                            placeholder="e.g. Sarah Connor"
                            value={learnForm.name} 
                            onChange={e => setLearnForm({...learnForm, name: e.target.value})}
                            className="w-full bg-white/[0.03] hover:bg-white/[0.05] focus:bg-black/40 border border-white/10 focus:border-white/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-white/20 transition-all duration-200"
                          />
                        </div>
                        <div className="relative group/input">
                          <label className="block text-[10px] font-mono font-bold uppercase tracking-widest text-white/50 mb-1.5 group-focus-within/input:text-white transition-colors">
                            Preferred Email Address
                          </label>
                          <input 
                            type="email" 
                            required 
                            placeholder="sarah@design-studio.com"
                            value={learnForm.email} 
                            onChange={e => setLearnForm({...learnForm, email: e.target.value})}
                            className="w-full bg-white/[0.03] hover:bg-white/[0.05] focus:bg-black/40 border border-white/10 focus:border-white/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-white/20 transition-all duration-200"
                          />
                        </div>
                        
                        <div className="pt-1">
                          <button 
                            type="submit" 
                            className="w-full bg-white hover:bg-neutral-100 text-black py-3 rounded-full text-xs font-bold uppercase tracking-wider hover:scale-[1.01] active:scale-[0.99] transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 border-none focus:outline-none shadow-lg shadow-white/5"
                          >
                            <span>Request Program Syllabus</span>
                            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                          </button>
                          <p className="text-[9px] text-center text-white/35 font-mono mt-3">
                            🔒 100% private. No promotional spam. Unsubscribe at any time.
                          </p>
                        </div>
                      </form>
                    )}
                  </div>
                </div>

                {/* Right Column: Curriculum Modules */}
                <div className="md:col-span-7 flex flex-col gap-6">
                  <div>
                    <h3 className="font-mono text-xs text-white/40 tracking-widest uppercase">CURRICULUM MODULES</h3>
                    <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">What you will learn</h2>
                  </div>

                  <div className="flex flex-col gap-4">
                    {activeCourse.modules.map((mod, idx) => (
                      <div 
                        key={idx}
                        className="bg-white/[0.02] border border-white/5 p-5 rounded-2xl flex flex-col gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <span className="flex-shrink-0 w-6 h-6 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[10px] font-mono text-white/60 font-semibold">
                            {idx + 1}
                          </span>
                          <h4 className="text-sm font-semibold text-white">
                            {mod.title}
                          </h4>
                        </div>
                        <p className="text-xs text-white/50 pl-9 -mt-1">
                          {mod.description}
                        </p>
                        
                        <div className="pl-9 mt-1 flex flex-col gap-2">
                          {mod.topics.map((topic, tIdx) => (
                            <div key={tIdx} className="flex items-start gap-2 text-xs text-white/80">
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 mt-0.5 flex-shrink-0" strokeWidth={2} />
                              <span className="leading-tight">{topic}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Bonus Resources (if available) */}
                  {activeCourse.bonus && activeCourse.bonus.length > 0 && (
                    <div className="mt-6 pt-6 border-t border-white/5 flex flex-col gap-4">
                      <div>
                        <h3 className="font-mono text-xs text-white/40 tracking-widest uppercase">EXCLUSIVE BONUS MATERIALS</h3>
                        <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">🎁 Premium Resources Included</h2>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {activeCourse.bonus.map((item, bIdx) => (
                          <div 
                            key={bIdx}
                            className="bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-white/10 p-4 rounded-xl flex items-center gap-3 transition-colors"
                          >
                            <span className="text-base flex-shrink-0">✨</span>
                            <span className="text-xs text-white/80 font-medium leading-snug">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Course Outcomes (if available) */}
                  {activeCourse.outcomes && activeCourse.outcomes.length > 0 && (
                    <div className="mt-6 pt-6 border-t border-white/5 flex flex-col gap-4">
                      <div>
                        <h3 className="font-mono text-xs text-white/40 tracking-widest uppercase">PROGRAM IMPACT</h3>
                        <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">🎯 What You Will Achieve</h2>
                      </div>
                      <div className="bg-emerald-500/[0.02] border border-emerald-500/10 p-6 rounded-3xl flex flex-col gap-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                          {activeCourse.outcomes.map((item, oIdx) => (
                            <div key={oIdx} className="flex items-start gap-3 text-xs text-white/90">
                              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center text-[10px] text-emerald-400 font-bold mt-0.5">
                                ✓
                              </span>
                              <span className="leading-relaxed font-medium">{item}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

              </div>

            </div>
          )}

        </div>
      </div>

    </div>
  );
}
