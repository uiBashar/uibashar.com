import React, { useState } from 'react';
import { ArrowLeft, BookOpen, Clock, Heart, Calendar, ArrowRight, Bookmark, Sparkles, Send, CheckCircle2 } from 'lucide-react';

const BG_IMAGE_1 = "https://github.com/uiBashar/uibashar.com/blob/main/bg1.jpg?raw=true";

interface Article {
  id: string;
  title: string;
  subtitle: string;
  tag: string;
  category: 'Design' | 'Engineering' | 'Interaction';
  date: string;
  readTime: string;
  description: string;
  image: string;
  content: {
    type: 'paragraph' | 'heading' | 'quote' | 'list';
    text?: string;
    items?: string[];
  }[];
  author: {
    name: string;
    role: string;
    avatar: string;
  };
}

const ARTICLES_DATA: Article[] = [
  {
    id: 'choreography-sound-motion',
    title: 'The Choreography of Sound and Motion',
    subtitle: 'TACTILE KINETIC DESIGN',
    tag: 'SOUND & MOTION',
    category: 'Interaction',
    date: 'July 2026',
    readTime: '6 min read',
    description: 'How micro-haptic audio feedback and spring-elastic transitions convert cold pixel displays into warm, organic, and tactile software systems.',
    image: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260328_105406_16f4600d-7a92-4292-b96e-b19156c7830a.mp4',
    author: {
      name: 'uiBashar Studio',
      role: 'Principal Design Engineer',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
    },
    content: [
      {
        type: 'paragraph',
        text: 'In the digital landscape, interfaces have historically been silent, rigid structures. We tap on flat glass plates, dragging cold rectangles across uniform matrices. But human perception did not evolve in a silent, flat world. We perceive physical matter through a complex choreography of resistance, sound, weight, and elasticity.'
      },
      {
        type: 'heading',
        text: 'The Physics of Tactility'
      },
      {
        type: 'paragraph',
        text: 'When we design interactions at uiBashar, we avoid linear ease-in-out animations. Linear movement is mechanical and foreign to human muscles. Instead, we rig our layouts with spring physics. Springs model real physical behavior: mass, tension, and damping. When a menu flies open with an elastic overshoot, it communicates weight and inertia, giving the user’s brain an intuitive visual anchor.'
      },
      {
        type: 'quote',
        text: '"A button that does not bounce slightly on release is a button that denies its own materiality. Software should yield to touch."'
      },
      {
        type: 'heading',
        text: 'Orchestrating Micro-Haptic Audio'
      },
      {
        type: 'paragraph',
        text: 'Sound is the fastest human sensory channel. By synthesizing extremely short, subtle audio frequencies during interactive states (hovering over items, clicking dials, completing operations), we trigger instant cognitive confirmation. We use the browser’s native Web Audio API to create transient oscillator clicks rather than using heavy, static MP3 files.'
      },
      {
        type: 'list',
        items: [
          'Oscillator Clicks: Short 5-15ms sine wave frequencies pitched around 800Hz - 1200Hz for a crisp tactile bump.',
          'State Choreography: Subtle audio pitch increases as sliders are dragged higher, providing auditory gradient feedback.',
          'Dampened Releases: Low-frequency square waves on cancellation actions to communicate system weight and error parameters.'
        ]
      },
      {
        type: 'paragraph',
        text: 'Integrating these micro-feedbacks into a unified spring system changes the software experience entirely. It stops looking like a flat grid and begins to feel like physical, tactile apparatus designed to bend, slide, and react directly to human play.'
      }
    ]
  },
  {
    id: 'beyond-rigid-grid',
    title: 'Designing Beyond the Rigid Grid',
    subtitle: 'FLUID RESPONSIVE RIGGING',
    tag: 'LAYOUT SYSTEMS',
    category: 'Design',
    date: 'June 2026',
    readTime: '5 min read',
    description: 'Transitioning from rigid design frameworks to fluid layouts that respond gracefully to device screen density and human biological patterns.',
    image: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260319_055001_8e16d972-3b2b-441c-86ad-2901a54682f9.mp4',
    author: {
      name: 'uiBashar Studio',
      role: 'Senior UI Architect',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
    },
    content: [
      {
        type: 'paragraph',
        text: 'Traditional web design was born from print layout standards. We divided the canvas into explicit containers, forced columns onto static grid setups, and set rigid breakpoints. But screen space is fluid, responsive, and diverse. A modern, multi-tier interface must adjust organically to any display ratio without jarring screen shifts.'
      },
      {
        type: 'heading',
        text: 'Fluid Typographical Scales'
      },
      {
        type: 'paragraph',
        text: 'Instead of building sudden breakpoint shifts (e.g., swapping `text-2xl` for `text-4xl` when crossing `768px`), we use mathematical typographic formulas with CSS clamp variables. This rigs font size to automatically transition smoothly between defined minimum and maximum bounds based on viewport width.'
      },
      {
        type: 'quote',
        text: '"True fluid design exists in the seamless transitions between states, not in the breakpoints themselves."'
      },
      {
        type: 'heading',
        text: 'Proportional Margin & Gap Rythms'
      },
      {
        type: 'paragraph',
        text: 'When layouts scale up, simply making text larger is a design failure. High-fidelity layouts require rhythm. We design spacing systems that adjust proportional padding based on relative card size and screen density. For instance, cards should have tight padding on mobile to prioritize readability, while expanding with breathing negative space on ultra-wide desktop monitors.'
      },
      {
        type: 'list',
        items: [
          'Responsive Containers: Utilizing maximum width constraints (`max-w-5xl` or `max-w-7xl`) to prevent visual stretching on widescreen monitors.',
          'Density Tuning: Using variable padding classes (`p-5 sm:p-6 md:p-8`) to shift layout weight dynamically.',
          'Structural Integrity: Aligning lines and borders precisely to build a clear, elegant hierarchy.'
        ]
      }
    ]
  },
  {
    id: 'frictionless-saas-interfaces',
    title: 'Designing Frictionless SaaS Interfaces',
    subtitle: 'PRODUCT ARCHITECTURE',
    tag: 'PRODUCT STRATEGY',
    category: 'Engineering',
    date: 'May 2026',
    readTime: '7 min read',
    description: 'Strategies to simplify complex multi-tier tables and dense forms into gorgeous, step-by-step visual stories that drive conversion.',
    image: 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260629_021419_291eb2af-5ed4-45a0-a1d6-3ef58f4bca0b.mp4',
    author: {
      name: 'uiBashar Studio',
      role: 'Principal Product Engineer',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
    },
    content: [
      {
        type: 'paragraph',
        text: 'SaaS interfaces are notoriously cluttered. Most software dashboard displays overwhelm users with dozens of data columns, infinite settings inputs, and confusing menu panels. Our core mission at uiBashar is to craft frictionless paths that distill this complex multi-tier information into clean, progressive interfaces.'
      },
      {
        type: 'heading',
        text: 'Progressive Disclosure'
      },
      {
        type: 'paragraph',
        text: 'Never show everything at once. Progressive disclosure is the golden rule of high-fidelity UX. We hide secondary settings, contextual logs, and advanced editing fields until the user explicitly requests them. This reduces cognitive overload, helping the user focus on completing their main task with zero cognitive strain.'
      },
      {
        type: 'quote',
        text: '"Cognitive load is the ultimate conversion killer. If a user has to think about where to click, the layout has failed."'
      },
      {
        type: 'heading',
        text: 'Eliminating Form Overhead'
      },
      {
        type: 'paragraph',
        text: 'Traditional multi-step forms feel like digital tax documents. We redesign these systems to utilize a single-view wizard layout. Using spring physics, inputs slide in gracefully as previous inputs are validated, turning data entry into an engaging, interactive narrative.'
      }
    ]
  }
];

interface ArticlesViewProps {
  onBackToHome: () => void;
  onOpenModal: (modal: any) => void;
}

export function ArticlesView({ onBackToHome, onOpenModal }: ArticlesViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Design' | 'Engineering' | 'Interaction'>('All');
  const [activeArticle, setActiveArticle] = useState<Article | null>(null);
  const [likedArticles, setLikedArticles] = useState<Record<string, boolean>>({});
  const [bookmarkedArticles, setBookmarkedArticles] = useState<Record<string, boolean>>({});
  const [commentText, setCommentText] = useState('');
  const [commentsList, setCommentsList] = useState<Record<string, string[]>>({});
  const [showSuccess, setShowSuccess] = useState(false);

  const toggleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedArticles(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedArticles(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const submitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !activeArticle) return;
    
    setCommentsList(prev => ({
      ...prev,
      [activeArticle.id]: [commentText, ...(prev[activeArticle.id] || [])]
    }));
    setCommentText('');
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const filteredArticles = selectedCategory === 'All' 
    ? ARTICLES_DATA 
    : ARTICLES_DATA.filter(a => a.category === selectedCategory);

  return (
    <div 
      className="min-h-screen bg-black text-white tracking-[-0.02em] relative overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Background artwork */}
      <div className="fixed inset-0 pointer-events-none z-10">
        <div 
          className="absolute inset-0 bg-center bg-cover bg-no-repeat" 
          style={{ backgroundImage: `url(${BG_IMAGE_1})` }}
        />
      </div>

      {/* Content wrapper */}
      <div className="relative z-20 min-h-screen overflow-y-auto pt-28 pb-20">
        <div className="max-w-5xl w-full mx-auto px-5 sm:px-8 md:px-10 flex flex-col gap-10">
          
          {!activeArticle ? (
            <>
              {/* Header Title & Categories Selector */}
              <div className="flex flex-col gap-4 animate-fade-in-up">
                <button 
                  onClick={onBackToHome}
                  className="group flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 hover:text-white transition-colors w-fit cursor-pointer bg-transparent border-none p-0 focus:outline-none"
                >
                  <span className="group-hover:-translate-x-1 transition-transform">←</span>
                  <span>Back to Home</span>
                </button>

                <div className="flex flex-col md:flex-row md:items-end justify-between gap-5">
                  <div>
                    <span className="font-mono text-xs text-white/40 tracking-widest uppercase">READS & PERSPECTIVES</span>
                    <h1 
                      className="text-3xl sm:text-4xl md:text-5xl font-medium tracking-tight text-white leading-[1.15] mt-1"
                      style={{ fontFamily: 'var(--font-heading)' }}
                    >
                      Articles
                    </h1>
                  </div>

                  {/* Filter Pills */}
                  <div className="flex items-center gap-1.5 bg-white/[0.04] border border-white/5 p-1 rounded-full w-full sm:w-fit overflow-x-auto scrollbar-none whitespace-nowrap max-w-full">
                    {(['All', 'Design', 'Engineering', 'Interaction'] as const).map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-4 py-1.5 rounded-full text-xs font-medium tracking-tight cursor-pointer transition-all duration-300 shrink-0 ${
                          selectedCategory === cat 
                            ? 'bg-white text-black font-semibold' 
                            : 'text-white/60 hover:text-white hover:bg-white/[0.02]'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Grid of Article Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredArticles.map((article) => {
                  const isLiked = likedArticles[article.id];
                  const isBookmarked = bookmarkedArticles[article.id];

                  return (
                    <div
                      key={article.id}
                      onClick={() => setActiveArticle(article)}
                      className="border border-white/10 bg-black/20 backdrop-blur-[3px] rounded-3xl overflow-hidden hover:border-white/25 hover:bg-black/30 transition-all duration-300 group cursor-pointer flex flex-col justify-between min-h-[380px] sm:min-h-[420px]"
                    >
                      {/* Top content - Image */}
                      <div className="relative overflow-hidden h-[180px] sm:h-[220px] w-full border-b border-white/5 bg-neutral-900/40">
                        {article.image.endsWith('.mp4') ? (
                          <video 
                            src={article.image}
                            autoPlay
                            loop
                            muted
                            playsInline
                            className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                          />
                        ) : (
                          <img 
                            src={article.image} 
                            alt={article.title}
                            className="absolute inset-0 w-full h-full object-cover object-top opacity-80 group-hover:opacity-100 group-hover:scale-[1.03] grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                            referrerPolicy="no-referrer"
                          />
                        )}
                        <div className="absolute top-4 left-4 flex gap-2">
                          <span className="font-mono text-[9px] font-semibold tracking-wider bg-black/60 text-white/90 px-2.5 py-1 rounded-full uppercase border border-white/10 backdrop-blur-md">
                            {article.tag}
                          </span>
                        </div>
                        <div className="absolute top-4 right-4 flex gap-2">
                          <button 
                            onClick={(e) => toggleLike(article.id, e)}
                            className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white/80 hover:text-white hover:scale-105 transition-all focus:outline-none"
                          >
                            <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-red-500 text-red-500' : 'text-white/80'}`} />
                          </button>
                          <button 
                            onClick={(e) => toggleBookmark(article.id, e)}
                            className="w-8 h-8 rounded-full bg-black/60 border border-white/10 flex items-center justify-center text-white/80 hover:text-white hover:scale-105 transition-all focus:outline-none"
                          >
                            <Bookmark className={`h-3.5 w-3.5 ${isBookmarked ? 'fill-emerald-400 text-emerald-400' : 'text-white/80'}`} />
                          </button>
                        </div>
                      </div>

                      {/* Article Title, Subtitle & Description */}
                      <div className="p-6 flex-1 flex flex-col justify-between gap-4">
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <h3 className="text-xl font-bold tracking-tight text-white group-hover:text-white/95">
                              {article.title}
                            </h3>
                            <span className="text-xs font-mono text-white/30 group-hover:text-white/60 transition-colors flex-shrink-0">
                              {article.date}
                            </span>
                          </div>
                          <p className="text-xs font-medium text-white/40 mt-0.5 uppercase tracking-wide">
                            {article.subtitle}
                          </p>
                          <p className="text-xs sm:text-sm text-white/60 leading-relaxed mt-2.5 line-clamp-3">
                            {article.description}
                          </p>
                        </div>

                        {/* Bottom Metadata & CTA */}
                        <div className="flex items-center justify-between pt-3 border-t border-white/5">
                          <div className="flex items-center gap-1.5 text-[11px] text-white/40 font-mono">
                            <Clock className="h-3 w-3" />
                            <span>{article.readTime}</span>
                          </div>
                          <span className="text-xs text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all flex items-center gap-1 font-semibold">
                            Read Article <span>→</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Showcase bottom panel */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-black/20 border border-white/10 p-6 rounded-3xl backdrop-blur-[3px]">
                <div className="max-w-md">
                  <span className="font-mono text-[10px] text-white/40 tracking-widest uppercase">STAY INSPIRED</span>
                  <h3 className="text-lg font-bold text-white mt-1">Want more custom visual breakdowns?</h3>
                  <p className="text-xs text-white/50 mt-1 leading-relaxed">
                    Subscribe to our educational workshops or join our mentorship masterclass to master physical interface rigging.
                  </p>
                </div>
                <button
                  onClick={() => onOpenModal('pitch')}
                  className="bg-white text-black font-semibold text-sm px-6 py-3 rounded-full hover:bg-neutral-200 transition-colors cursor-pointer w-full md:w-auto text-center border-none focus:outline-none"
                >
                  Join Masterclass
                </button>
              </div>
            </>
          ) : (
            /* Immersive Article Reader View */
            <div className="flex flex-col gap-6 animate-fade-in-up">
              
              {/* Back Link */}
              <div className="flex items-center">
                <button 
                  onClick={() => {
                    setActiveArticle(null);
                    setCommentText('');
                  }}
                  className="group flex items-center gap-2 text-xs uppercase tracking-widest text-white/50 hover:text-white transition-colors w-fit cursor-pointer bg-transparent border-none p-0 focus:outline-none"
                >
                  <span className="group-hover:-translate-x-1 transition-transform">←</span>
                  <span>Back to Articles</span>
                </button>
              </div>

              {/* Layout Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-start mt-2">
                
                {/* Left Side: Article Hero Image & Floating Controls */}
                <div className="md:col-span-5 flex flex-col gap-6">
                  <div className="relative overflow-hidden aspect-video sm:aspect-square rounded-3xl border border-white/10 bg-neutral-900/50 group cursor-pointer">
                    {activeArticle.image.endsWith('.mp4') ? (
                      <video 
                        src={activeArticle.image}
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                      />
                    ) : (
                      <img 
                        src={activeArticle.image} 
                        alt={activeArticle.title}
                        className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-out"
                        referrerPolicy="no-referrer"
                      />
                    )}
                    <div className="absolute top-4 left-4">
                      <span className="font-mono text-[9px] font-semibold tracking-wider bg-black/80 text-white/90 px-3 py-1.5 rounded-full uppercase border border-white/10 backdrop-blur-md">
                        {activeArticle.tag}
                      </span>
                    </div>
                  </div>

                  {/* Metadata Sidebar block */}
                  <div className="bg-white/[0.02] border border-white/5 p-5 rounded-2xl flex flex-col gap-4">
                    <div className="flex items-center gap-3">
                      <img 
                        src={activeArticle.author.avatar} 
                        alt={activeArticle.author.name}
                        className="w-10 h-10 rounded-full border border-white/10 object-cover"
                      />
                      <div>
                        <h4 className="text-xs font-semibold text-white">{activeArticle.author.name}</h4>
                        <p className="text-[10px] text-white/40">{activeArticle.author.role}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-3 border-t border-white/5">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-[9px] font-mono text-white/40 uppercase">Published</span>
                        <span className="text-xs text-white/80 font-medium">{activeArticle.date}</span>
                      </div>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-[9px] font-mono text-white/40 uppercase">Read Time</span>
                        <span className="text-xs text-white/80 font-medium">{activeArticle.readTime}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-white/5">
                      <span className="text-[10px] text-white/40 uppercase font-mono">Like this article?</span>
                      <div className="flex gap-2">
                        <button 
                          onClick={(e) => toggleLike(activeArticle.id, e)}
                          className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all ${
                            likedArticles[activeArticle.id] 
                              ? 'bg-red-500/15 border-red-500/30 text-red-500' 
                              : 'bg-white/5 border-white/10 text-white/80 hover:text-white'
                          }`}
                        >
                          <Heart className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={(e) => toggleBookmark(activeArticle.id, e)}
                          className={`w-9 h-9 rounded-full border flex items-center justify-center transition-all ${
                            bookmarkedArticles[activeArticle.id] 
                              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400' 
                              : 'bg-white/5 border-white/10 text-white/80 hover:text-white'
                          }`}
                        >
                          <Bookmark className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Feedback / Booking Block */}
                  <div className="bg-black/20 border border-white/10 p-5 rounded-2xl backdrop-blur-[3px]">
                    <h4 className="text-xs font-semibold text-white flex items-center gap-1.5 uppercase tracking-wider">
                      <Sparkles className="h-3.5 w-3.5 text-white/60" />
                      Interactive Workshop
                    </h4>
                    <p className="text-[11px] text-white/50 mt-1 leading-relaxed">
                      We offer a 1-on-1 micro-interaction review corresponding to this topic. Rig your code with real expert feedback.
                    </p>
                    <button 
                      onClick={() => onOpenModal('pitch')}
                      className="w-full bg-white text-black font-semibold text-xs py-2 rounded-full mt-3.5 hover:opacity-90 transition-opacity cursor-pointer border-none focus:outline-none"
                    >
                      Book Mentorship Session
                    </button>
                  </div>
                </div>

                {/* Right Side: Article Rich Content & Comments */}
                <div className="md:col-span-7 flex flex-col gap-8">
                  <div className="flex flex-col gap-2">
                    <span className="font-mono text-xs text-emerald-400 font-semibold uppercase tracking-widest">
                      {activeArticle.category} Article
                    </span>
                    <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white leading-[1.15]">
                      {activeArticle.title}
                    </h1>
                    <p className="text-sm font-medium text-white/50 uppercase tracking-wide">
                      {activeArticle.subtitle}
                    </p>
                  </div>

                  {/* Body Content Blocks */}
                  <div className="flex flex-col gap-6 text-sm text-white/80 leading-relaxed font-light">
                    {activeArticle.content.map((block, idx) => {
                      if (block.type === 'heading') {
                        return (
                          <h2 key={idx} className="text-lg sm:text-xl font-bold text-white tracking-tight mt-4">
                            {block.text}
                          </h2>
                        );
                      }
                      if (block.type === 'quote') {
                        return (
                          <div key={idx} className="border-l-2 border-white/40 pl-4 py-1 italic text-white/90 bg-white/[0.01] my-2">
                            {block.text}
                          </div>
                        );
                      }
                      if (block.type === 'list') {
                        return (
                          <div key={idx} className="flex flex-col gap-3 my-2 bg-white/[0.01] border border-white/5 p-4 rounded-xl">
                            {block.items?.map((item, itemIdx) => (
                              <div key={itemIdx} className="flex items-start gap-2 text-xs text-white/75">
                                <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 flex-shrink-0" strokeWidth={2} />
                                <span>{item}</span>
                              </div>
                            ))}
                          </div>
                        );
                      }
                      return (
                        <p key={idx}>
                          {block.text}
                        </p>
                      );
                    })}
                  </div>

                  {/* Commentary / Discussion section */}
                  <div className="pt-8 border-t border-white/10 flex flex-col gap-5">
                    <div>
                      <h3 className="font-mono text-xs text-white/40 tracking-widest uppercase">DISCUSS / INSIGHTS</h3>
                      <h2 className="text-lg sm:text-xl font-bold text-white mt-1">Reader Comments</h2>
                    </div>

                    <form onSubmit={submitComment} className="flex flex-col gap-3">
                      <div className="relative">
                        <textarea 
                          rows={3}
                          required
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          placeholder="Share your thoughts on this architecture..."
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-white resize-none"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-white/30">Comments are approved instantly.</span>
                        <button 
                          type="submit" 
                          className="bg-white text-black px-4 py-2 rounded-full text-xs font-semibold hover:opacity-95 transition-opacity flex items-center gap-1.5 cursor-pointer border-none focus:outline-none"
                        >
                          <span>Post Comment</span>
                          <Send className="h-3 w-3" />
                        </button>
                      </div>
                    </form>

                    {showSuccess && (
                      <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl text-center">
                        <span className="text-emerald-400 text-xs font-semibold">Comment posted successfully!</span>
                      </div>
                    )}

                    {/* Comments List */}
                    <div className="flex flex-col gap-4 mt-2">
                      {(commentsList[activeArticle.id] || []).map((comment, idx) => (
                        <div key={idx} className="bg-white/[0.02] border border-white/5 p-4 rounded-xl flex flex-col gap-1.5 animate-fade-in-up">
                          <div className="flex justify-between items-center">
                            <span className="text-[11px] font-semibold text-white/80">Anonymous Designer</span>
                            <span className="text-[9px] font-mono text-white/30">Just now</span>
                          </div>
                          <p className="text-xs text-white/70 leading-relaxed font-light">
                            {comment}
                          </p>
                        </div>
                      ))}

                      {/* Mock community comments for richness */}
                      <div className="bg-white/[0.02] border border-white/5 p-4 rounded-xl flex flex-col gap-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-[11px] font-semibold text-white/80">Marcus V.</span>
                          <span className="text-[9px] font-mono text-white/30">2 days ago</span>
                        </div>
                        <p className="text-xs text-white/70 leading-relaxed font-light">
                          The point on micro-haptics is key. I implemented Web Audio oscillators in a dashboard project last month, and the speed of sensory feedback was immediately noted by the client. Thanks for the breakdown!
                        </p>
                      </div>

                      <div className="bg-white/[0.02] border border-white/5 p-4 rounded-xl flex flex-col gap-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-[11px] font-semibold text-white/80">Elena Rostova</span>
                          <span className="text-[9px] font-mono text-white/30">1 week ago</span>
                        </div>
                        <p className="text-xs text-white/70 leading-relaxed font-light">
                          I really love the typographic scales explanation. Dealing with grid-shatters is so frustrating. Using pure CSS clamp logic makes the whole application feel unified.
                        </p>
                      </div>
                    </div>
                  </div>

                </div>

              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
}
